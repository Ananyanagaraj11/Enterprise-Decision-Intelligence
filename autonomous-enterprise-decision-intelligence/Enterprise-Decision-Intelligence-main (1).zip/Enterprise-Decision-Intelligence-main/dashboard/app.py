"""Streamlit UI: multi-tab EDI (Plotly). Uses run_pipeline."""

from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from enterprise_decision_intel.config import detection_sensitivity
from enterprise_decision_intel.data_pipeline import load_ga4_style_csv
from enterprise_decision_intel.evaluation.runner import evaluation_table, run_evaluation
from enterprise_decision_intel.pipeline import run_pipeline

# --- Theme (high contrast dark; Streamlit + Plotly legend readability) -----
THEME_CSS = """
<style>
    /* Global */
    .stApp {
        background-color: #0b1220 !important;
        color: #e5e7eb !important;
    }
    .main .block-container {
        color: #e5e7eb !important;
    }

    /* Sidebar */
    [data-testid="stSidebar"],
    section[data-testid="stSidebar"] {
        background-color: #111827 !important;
        border-right: 1px solid #1f2937 !important;
    }
    [data-testid="stSidebar"] .stMarkdown,
    [data-testid="stSidebar"] label,
    [data-testid="stSidebar"] span,
    [data-testid="stSidebar"] p,
    [data-testid="stSidebar"] div[data-testid="stWidgetLabel"] p {
        color: #e5e7eb !important;
    }

    /* Headings & body text */
    h1, h2, h3, h4, h5, h6 {
        color: #f9fafb !important;
    }
    p, span, label {
        color: #e5e7eb !important;
    }

    /* Metrics — no faded wrapper; force readable values */
    [data-testid="stMetricContainer"] {
        background: transparent !important;
        border: none !important;
        padding: 0 !important;
        opacity: 1 !important;
    }
    [data-testid="stMetricValue"] {
        color: #ffffff !important;
        font-size: 1.5rem !important;
        font-weight: 700 !important;
        opacity: 1 !important;
    }
    [data-testid="stMetricLabel"] {
        color: #d1d5db !important;
        opacity: 1 !important;
    }
    [data-testid="stMetricDelta"] {
        color: #10b981 !important;
        opacity: 1 !important;
    }

    /* Primary & default buttons */
    .stButton > button,
    button[kind="primary"],
    button[kind="secondary"] {
        background-color: #3b82f6 !important;
        color: #ffffff !important;
        border-radius: 8px !important;
        border: 1px solid #2563eb !important;
        font-weight: 600 !important;
        opacity: 1 !important;
    }
    .stButton > button:hover {
        background-color: #2563eb !important;
        color: #ffffff !important;
        border-color: #1d4ed8 !important;
    }

    /* Download buttons */
    .stDownloadButton > button,
    [data-testid="stDownloadButton"] button {
        background-color: #10b981 !important;
        color: #ffffff !important;
        border-radius: 8px !important;
        border: 1px solid #059669 !important;
        font-weight: 600 !important;
        opacity: 1 !important;
    }
    .stDownloadButton > button:hover {
        background-color: #059669 !important;
        color: #ffffff !important;
    }

    /* File uploader */
    [data-testid="stFileUploader"] {
        background-color: #1f2937 !important;
        border-radius: 10px !important;
        padding: 10px !important;
        border: 1px solid #374151 !important;
    }
    [data-testid="stFileUploader"] section,
    [data-testid="stFileUploader"] [data-testid="stFileUploaderDropzone"] {
        background-color: #374151 !important;
        border-color: #4b5563 !important;
    }
    [data-testid="stFileUploader"] small,
    [data-testid="stFileUploader"] span,
    [data-testid="stFileUploader"] label,
    [data-testid="stFileUploader"] p {
        color: #e5e7eb !important;
        opacity: 1 !important;
    }
    [data-testid="stFileUploader"] button {
        background-color: #3b82f6 !important;
        color: #ffffff !important;
        border: none !important;
        font-weight: 600 !important;
    }

    /* Select boxes, inputs (dark surfaces, light text) */
    [data-testid="stSelectbox"] div[data-baseweb="select"] > div,
    [data-baseweb="select"] > div {
        background-color: #1f2937 !important;
        border-color: #374151 !important;
        color: #f9fafb !important;
    }
    [data-baseweb="select"] span {
        color: #f9fafb !important;
    }

    /* Slider */
    [data-testid="stSlider"] label,
    [data-testid="stSlider"] span {
        color: #e5e7eb !important;
    }

    /* Checkbox / toggle */
    [data-testid="stCheckbox"] label,
    [data-testid="stMarkdownContainer"] p {
        color: #e5e7eb !important;
    }

    /* Tabs — spacing so labels don’t read as one word */
    .stTabs [data-baseweb="tab-list"] {
        background: #111827 !important;
        border-radius: 8px !important;
        border: 1px solid #1f2937 !important;
        gap: 10px !important;
        padding: 8px 12px !important;
        flex-wrap: wrap !important;
        align-items: center !important;
    }
    .stTabs [data-baseweb="tab-list"] > div {
        padding: 0 2px !important;
    }
    .stTabs [data-baseweb="tab"] {
        color: #d1d5db !important;
        border-radius: 6px !important;
        padding: 10px 20px !important;
        margin: 0 2px !important;
        white-space: nowrap !important;
    }
    .stTabs [aria-selected="true"] {
        background: #1e3a5f !important;
        color: #f9fafb !important;
        border: 1px solid #3b82f6 !important;
    }

    .stCaption, [data-testid="stCaptionContainer"] {
        color: #9ca3af !important;
        opacity: 1 !important;
    }
    [data-testid="stExpander"] {
        background: #111827 !important;
        border: 1px solid #1f2937 !important;
    }
    /* Info / warning boxes */
    .stAlert {
        opacity: 1 !important;
    }
</style>
"""

# Plotly legend (readable on dark plot area)
PLOTLY_LEGEND_FONT = dict(color="#f9fafb", size=12)

# Axis grid only — merge titles/range into these dicts per chart (avoid xaxis_title/yaxis_title + yaxis conflicts).
AXIS_GRID_X = dict(gridcolor="#1f2937", zerolinecolor="#374151")
AXIS_GRID_Y = dict(gridcolor="#1f2937", zerolinecolor="#374151")

PLOTLY_LAYOUT_BASE = dict(
    paper_bgcolor="#0b1220",
    plot_bgcolor="#0b1220",
    font=dict(color="#e5e7eb", size=12),
    colorway=["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#a78bfa"],
    hoverlabel=dict(bgcolor="#111827", font_size=12),
)
# Margins are set per figure (not in BASE) to avoid duplicate `margin` kwargs with **PLOTLY_LAYOUT_BASE.
PLOTLY_MARGIN_DEFAULT = dict(l=48, r=24, t=48, b=48)
PLOTLY_MARGIN_LOOSE = dict(l=56, r=28, t=56, b=52)
PLOTLY_MARGIN_HIST = dict(l=56, r=28, t=52, b=52)

TRANSITION = dict(duration=500, easing="cubic-in-out")  # Plotly layout.transition

PLOTLY_MARGIN_COMBO = dict(l=56, r=28, t=56, b=100)  # room for horizontal legend


def _inject_theme() -> None:
    st.markdown(THEME_CSS, unsafe_allow_html=True)


# --- Data loading (cached) -------------------------------------------------
@st.cache_data(show_spinner=False)
def _cached_load_csv(path_str: str, mtime: float) -> pd.DataFrame:
    return load_ga4_style_csv(path_str)


def _load_uploaded_df(blob: bytes) -> pd.DataFrame:
    """Not cached (avoid storing large byte blobs in cache keys)."""
    with tempfile.NamedTemporaryFile(mode="wb", suffix=".csv", delete=False) as tmp:
        tmp.write(blob)
        p = tmp.name
    try:
        return load_ga4_style_csv(p)
    finally:
        Path(p).unlink(missing_ok=True)


def _dim_suffixes(df: pd.DataFrame, prefix: str) -> list[str]:
    return sorted({c.replace(prefix, "") for c in df.columns if c.startswith(prefix)})


def _effective_metric_col(
    df: pd.DataFrame,
    base_metric: str,
    region_sel: str,
    segment_sel: str,
    tier_sel: str,
) -> str:
    if region_sel != "All":
        c = f"rev_region_{region_sel}"
        if c in df.columns:
            return c
    if segment_sel != "All":
        c = f"rev_customer_segment_{segment_sel}"
        if c in df.columns:
            return c
    if tier_sel != "All":
        c = f"rev_product_tier_{tier_sel}"
        if c in df.columns:
            return c
    return base_metric


def _filter_date_range(df: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
    d = pd.to_datetime(df["date"])
    m = (d >= pd.Timestamp(start).normalize()) & (d <= pd.Timestamp(end).normalize())
    return df.loc[m].reset_index(drop=True)


def _append_log(msg: str) -> None:
    ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
    st.session_state.setdefault("log_lines", [])
    st.session_state["log_lines"].append(f"[{ts} UTC] {msg}")
    if len(st.session_state["log_lines"]) > 500:
        st.session_state["log_lines"] = st.session_state["log_lines"][-500:]


def _merge_traces_to_df(df: pd.DataFrame, traces: list[dict]) -> pd.DataFrame:
    rows = []
    for t in traces:
        rows.append(
            {
                "date": pd.Timestamp(t.get("date")).normalize(),
                "is_anomaly": bool(t.get("is_anomaly")),
                "anomaly_score": t.get("anomaly_score"),
                "confidence": t.get("confidence"),
                "execution_status": t.get("execution_status"),
            }
        )
    tdf = pd.DataFrame(rows)
    out = df.copy()
    out["date"] = pd.to_datetime(out["date"]).dt.normalize()
    return out.merge(tdf, on="date", how="left")


def _simple_linear_forecast(dates: pd.Series, y: pd.Series, horizon: int = 7) -> tuple[pd.DatetimeIndex, list[float]]:
    y = pd.to_numeric(y, errors="coerce").ffill().fillna(0.0)
    n = min(28, len(y))
    if n < 3:
        return pd.DatetimeIndex([]), []
    ys = y.iloc[-n:].values.astype(float)
    xs = pd.to_datetime(dates.iloc[-n:]).map(pd.Timestamp.toordinal).values.astype(float)
    x_mean, y_mean = xs.mean(), ys.mean()
    denom = ((xs - x_mean) ** 2).sum()
    if denom < 1e-12:
        slope = 0.0
    else:
        slope = ((xs - x_mean) * (ys - y_mean)).sum() / denom
    intercept = y_mean - slope * x_mean
    last_d = pd.Timestamp(dates.iloc[-1]).normalize()
    future = pd.date_range(last_d + pd.Timedelta(days=1), periods=horizon, freq="D")
    preds = [float(intercept + slope * pd.Timestamp(d).toordinal()) for d in future]
    return future, preds


def _trace_lookup_by_date(traces: list[dict]) -> dict[pd.Timestamp, dict]:
    out: dict[pd.Timestamp, dict] = {}
    for t in traces:
        d = pd.Timestamp(t.get("date")).normalize()
        out[d] = {
            "is_anomaly": bool(t.get("is_anomaly")),
            "anomaly_score": t.get("anomaly_score"),
        }
    return out


def _plotly_kpi_trend_forecast_combo(
    df: pd.DataFrame,
    metric_col: str,
    traces: list[dict],
    *,
    rolling_window: int,
    show_anomalies: bool,
    viz_score_min: float,
    show_forecast: bool,
) -> go.Figure:
    """Single production chart: actuals, rolling mean, ±1σ band, 7d forecast, anomaly markers (rich hover)."""
    x = pd.to_datetime(df["date"])
    y = pd.to_numeric(df[metric_col], errors="coerce").astype(float)
    win = max(2, int(rolling_window))
    min_periods = max(2, min(win, max(2, win // 2)))
    mu = y.rolling(win, min_periods=min_periods).mean()
    sig = y.rolling(win, min_periods=min_periods).std()
    upper = (mu + sig).where(mu.notna())
    lower = (mu - sig).where(mu.notna())
    lookup = _trace_lookup_by_date(traces)

    fig = go.Figure()
    # ±1σ band (local rolling)
    fig.add_trace(
        go.Scatter(
            x=x,
            y=upper,
            mode="lines",
            line=dict(width=0),
            showlegend=False,
            hoverinfo="skip",
            name="_upper",
        )
    )
    fig.add_trace(
        go.Scatter(
            x=x,
            y=lower,
            mode="lines",
            line=dict(width=0),
            fill="tonexty",
            fillcolor="rgba(245, 158, 11, 0.14)",
            name="±1σ band (local)",
            hoverinfo="skip",
        )
    )
    fig.add_trace(
        go.Scatter(
            x=x,
            y=mu,
            mode="lines",
            name=f"{win}d trend (mean)",
            line=dict(color="#f59e0b", width=2),
            hovertemplate="Date: %{x|%Y-%m-%d}<br>Trend (mean): %{y:,.4f}<extra></extra>",
        )
    )
    fig.add_trace(
        go.Scatter(
            x=x,
            y=y,
            mode="lines",
            name=str(metric_col),
            line=dict(color="#3b82f6", width=2.5),
            hovertemplate=(
                f"Date: %{{x|%Y-%m-%d}}<br>{metric_col}: %{{y:,.4f}}<extra></extra>"
            ),
        )
    )
    if show_forecast:
        fut, pred = _simple_linear_forecast(x, y, horizon=7)
        if len(fut):
            fig.add_trace(
                go.Scatter(
                    x=fut,
                    y=pred,
                    mode="lines",
                    name="7-day forecast",
                    line=dict(color="#10b981", width=2, dash="dash"),
                    hovertemplate="Date: %{x|%Y-%m-%d}<br>Forecast: %{y:,.4f}<extra></extra>",
                )
            )
    if show_anomalies:
        ax, ay, cd = [], [], []
        for i in range(len(x)):
            d = pd.Timestamp(x.iloc[i]).normalize()
            info = lookup.get(d) or {}
            if not info.get("is_anomaly"):
                continue
            sc = float(info.get("anomaly_score") or 0.0)
            if sc < float(viz_score_min):
                continue
            exp = float(mu.iloc[i]) if pd.notna(mu.iloc[i]) else float("nan")
            ax.append(x.iloc[i])
            ay.append(float(y.iloc[i]))
            cd.append([float(y.iloc[i]), exp, sc])
        if ax:
            cda = np.asarray(cd, dtype=float)
            fig.add_trace(
                go.Scatter(
                    x=ax,
                    y=ay,
                    mode="markers",
                    name="anomaly",
                    marker=dict(color="#ef4444", size=12, line=dict(width=2, color="#fecaca")),
                    customdata=cda,
                    hovertemplate=(
                        "Date: %{x|%Y-%m-%d}<br>"
                        "Value: %{customdata[0]:,.4f}<br>"
                        "Expected (trend): %{customdata[1]:,.4f}<br>"
                        "Anomaly score: %{customdata[2]:.3f}<extra></extra>"
                    ),
                )
            )

    fig.update_layout(
        title=dict(
            text=f"{metric_col}: trend, ±1σ band & 7-day forecast",
            font=dict(size=17, color="#f3f4f6"),
            x=0.01,
            xanchor="left",
            y=0.98,
            yanchor="top",
        ),
        **PLOTLY_LAYOUT_BASE,
        margin=PLOTLY_MARGIN_COMBO,
        legend=dict(
            orientation="h",
            yanchor="top",
            y=-0.22,
            x=0.5,
            xanchor="center",
            font=PLOTLY_LEGEND_FONT,
            bgcolor="rgba(17,24,39,0.92)",
            bordercolor="#374151",
            borderwidth=1,
            itemsizing="constant",
            itemwidth=30,
        ),
        xaxis={
            **AXIS_GRID_X,
            "showgrid": False,
            "title": dict(text="Date", font=dict(color="#e5e7eb", size=12)),
        },
        yaxis={
            **AXIS_GRID_Y,
            "showgrid": True,
            "gridcolor": "#1f2937",
            "title": dict(text=str(metric_col), font=dict(color="#e5e7eb", size=12)),
        },
        transition=TRANSITION,
    )
    return fig


def _plotly_anomaly_severity_distribution(
    traces: list[dict],
    *,
    flagged_only: bool = False,
    show_kde: bool = True,
) -> go.Figure:
    """Histogram of anomaly scores with severity coloring, threshold guides, optional KDE."""
    scores: list[float] = []
    for t in traces:
        if flagged_only and not t.get("is_anomaly"):
            continue
        if t.get("anomaly_score") is None:
            continue
        scores.append(float(t["anomaly_score"]))
    if not scores:
        scores = [0.0]

    scores_arr = np.asarray(scores, dtype=float)
    n_bins = int(min(28, max(14, len(scores) // 2)))
    counts, edges = np.histogram(scores_arr, bins=n_bins)
    centers = (edges[:-1] + edges[1:]) / 2.0
    widths = np.diff(edges)
    bar_colors = []
    for c in centers:
        if c < 1.0:
            bar_colors.append("#10b981")
        elif c < 2.0:
            bar_colors.append("#f59e0b")
        else:
            bar_colors.append("#ef4444")

    fig = go.Figure()
    fig.add_trace(
        go.Bar(
            x=centers,
            y=counts,
            width=widths * 0.92,
            marker=dict(color=bar_colors, line=dict(color="#111827", width=1)),
            opacity=0.88,
            name="Days",
            hovertemplate="Score bin (center): %{x:.3f}<br>Count: %{y}<extra></extra>",
        )
    )

    ymax = float(np.max(counts)) if len(counts) else 1.0
    fig.add_vline(x=1.0, line_dash="dash", line_color="#f59e0b", line_width=2)
    fig.add_vline(x=2.0, line_dash="dash", line_color="#ef4444", line_width=2)

    fig.add_annotation(
        x=0.45,
        y=ymax * 1.06,
        text="Normal",
        showarrow=False,
        font=dict(color="#10b981", size=12),
        xref="x",
        yref="y",
    )
    fig.add_annotation(
        x=1.35,
        y=ymax * 1.06,
        text="Warning",
        showarrow=False,
        font=dict(color="#f59e0b", size=12),
        xref="x",
        yref="y",
    )
    fig.add_annotation(
        x=min(2.65, float(np.max(scores_arr)) + 0.1),
        y=ymax * 1.06,
        text="Critical",
        showarrow=False,
        font=dict(color="#ef4444", size=12),
        xref="x",
        yref="y",
    )

    if show_kde and len(scores_arr) > 4 and float(np.std(scores_arr)) > 1e-9:
        try:
            from scipy.stats import gaussian_kde

            kde = gaussian_kde(scores_arr)
            xs = np.linspace(float(np.min(scores_arr)), float(np.max(scores_arr)), 120)
            dens = kde(xs)
            if np.max(dens) > 0:
                scale = 0.42 * ymax / float(np.max(dens))
                fig.add_trace(
                    go.Scatter(
                        x=xs,
                        y=dens * scale,
                        mode="lines",
                        name="density (scaled)",
                        line=dict(color="#94a3b8", width=2),
                        hovertemplate="Score: %{x:.3f}<br>Scaled density: %{y:.2f}<extra></extra>",
                    )
                )
        except Exception:
            pass

    subtitle = " (flagged days only)" if flagged_only else " (all days)"
    fig.update_layout(
        title=dict(
            text=f"Anomaly severity distribution{subtitle}",
            font=dict(size=16, color="#f3f4f6"),
        ),
        **PLOTLY_LAYOUT_BASE,
        xaxis={
            **AXIS_GRID_X,
            "showgrid": False,
            "title": dict(text="Anomaly score", font=dict(color="#e5e7eb", size=12)),
        },
        yaxis={
            **AXIS_GRID_Y,
            "showgrid": True,
            "gridcolor": "#1f2937",
            "title": dict(text="Day count", font=dict(color="#e5e7eb", size=12)),
        },
        legend=dict(font=PLOTLY_LEGEND_FONT),
        margin=dict(l=56, r=28, t=72, b=52),
        bargap=0.08,
        transition=TRANSITION,
    )
    return fig


def _plotly_anomaly_scores(traces: list[dict], df: pd.DataFrame, metric_col: str) -> go.Figure:
    rows = []
    for t in traces:
        rows.append(
            {
                "date": pd.Timestamp(t.get("date")),
                "score": float(t.get("anomaly_score") or 0.0),
                "flag": bool(t.get("is_anomaly")),
            }
        )
    tdf = pd.DataFrame(rows)
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=tdf["date"],
            y=tdf["score"],
            mode="lines",
            name="score",
            line=dict(color="#a78bfa", width=2),
        )
    )
    sub = tdf[tdf["flag"]]
    if not sub.empty:
        fig.add_trace(
            go.Scatter(
                x=sub["date"],
                y=sub["score"],
                mode="markers",
                name="flagged",
                marker=dict(color="#ef4444", size=10),
            )
        )
    fig.update_layout(
        title=dict(
            text=f"Anomaly score over time · KPI context: {metric_col}",
            font=dict(size=14, color="#f3f4f6"),
            x=0.01,
            xanchor="left",
            y=0.98,
            yanchor="top",
        ),
        **PLOTLY_LAYOUT_BASE,
        margin=PLOTLY_MARGIN_LOOSE,
        legend=dict(
            orientation="v",
            yanchor="top",
            y=0.99,
            x=0.99,
            xanchor="right",
            font=PLOTLY_LEGEND_FONT,
            bgcolor="rgba(17,24,39,0.82)",
            bordercolor="#374151",
            borderwidth=1,
            itemwidth=30,
        ),
        xaxis={**AXIS_GRID_X, "title": dict(text="date", font=dict(color="#e5e7eb", size=12))},
        yaxis={**AXIS_GRID_Y, "title": dict(text="score", font=dict(color="#e5e7eb", size=12))},
        transition=TRANSITION,
    )
    return fig


def _plotly_rca_bars(root_causes: list[dict]) -> go.Figure:
    if not root_causes:
        fig = go.Figure()
        fig.update_layout(
            title=dict(text="Root causes (selected day)", font=dict(size=14, color="#9ca3af")),
            **PLOTLY_LAYOUT_BASE,
            margin=PLOTLY_MARGIN_DEFAULT,
            annotations=[dict(text="No RCA rows", x=0.5, y=0.5, showarrow=False, font=dict(color="#9ca3af"))],
            xaxis={**AXIS_GRID_X},
            yaxis={**AXIS_GRID_Y},
            legend=dict(font=PLOTLY_LEGEND_FONT),
        )
        return fig
    labels = [
        f"{r.get('dimension', '—')}:{r.get('value', '—')}" if isinstance(r, dict) else "—"
        for r in root_causes
    ]
    vals = []
    for r in root_causes:
        if not isinstance(r, dict):
            vals.append(0.0)
            continue
        v = r.get("contribution_pct")
        if v is None:
            v = r.get("pct") or r.get("score") or 0.0
        vals.append(float(v))
    fig = go.Figure(
        go.Bar(
            x=vals,
            y=labels,
            orientation="h",
            marker=dict(color="#3b82f6", line=dict(color="#1d4ed8", width=1)),
        )
    )
    fig.update_layout(
        title=dict(text="Root cause contribution (%)", font=dict(size=14, color="#f3f4f6")),
        **PLOTLY_LAYOUT_BASE,
        margin=PLOTLY_MARGIN_DEFAULT,
        xaxis={**AXIS_GRID_X, "title": dict(text="%", font=dict(color="#e5e7eb", size=12))},
        yaxis={**AXIS_GRID_Y, "title": dict(text="", font=dict(color="#e5e7eb", size=12))},
        legend=dict(font=PLOTLY_LEGEND_FONT),
        transition=TRANSITION,
    )
    return fig


def _eval_column_config() -> dict[str, object]:
    """Tighter column widths so metric headers line up with numeric cells."""
    cc = st.column_config
    return {
        "system": cc.TextColumn("System", width="medium"),
        "precision": cc.NumberColumn("Precision", format="%.4f"),
        "recall": cc.NumberColumn("Recall", format="%.4f"),
        "f1": cc.NumberColumn("F1 / score", format="%.4f"),
    }


def _plotly_eval_bars(agent_row: dict) -> go.Figure:
    metrics = ["precision", "recall", "f1"]
    vals = [float(agent_row.get(k) or 0.0) for k in metrics]
    fig = go.Figure(
        go.Bar(
            x=metrics,
            y=vals,
            marker=dict(color=["#3b82f6", "#10b981", "#f59e0b"]),
            text=[f"{v:.3f}" for v in vals],
            textposition="outside",
        )
    )
    fig.update_layout(
        title=dict(text="Agentic detector (inject eval)", font=dict(size=14, color="#f3f4f6")),
        **PLOTLY_LAYOUT_BASE,
        margin=PLOTLY_MARGIN_DEFAULT,
        xaxis={**AXIS_GRID_X, "title": dict(text="", font=dict(color="#e5e7eb", size=12))},
        yaxis={
            **AXIS_GRID_Y,
            "title": dict(text="value", font=dict(color="#e5e7eb", size=12)),
            "range": [0, 1.05],
        },
        legend=dict(font=PLOTLY_LEGEND_FONT),
        transition=TRANSITION,
    )
    return fig


def _normalize_rc_rows(focus: dict) -> list[dict]:
    ranked = focus.get("root_causes_ranked") or []
    out = []
    for r in ranked:
        if isinstance(r, dict):
            out.append(r)
    return out


def main() -> None:
    st.set_page_config(
        page_title="Enterprise Decision Intelligence",
        layout="wide",
        initial_sidebar_state="expanded",
    )
    _inject_theme()

    st.markdown(
        "<h1 style='margin-bottom:0.25rem;'>Enterprise Decision Intelligence <span style='color:#3b82f6'>(EDI)</span></h1>"
        "<p style='color:#9ca3af;margin-top:0;'>Interactive UI · real pipeline outputs</p>",
        unsafe_allow_html=True,
    )

    # Session defaults
    for k, v in {
        "traces": None,
        "df_run": None,
        "metric_effective": None,
        "eval_report": None,
        "eval_table": None,
        "window": 14,
        "log_lines": [],
        "last_focus_idx": 0,
    }.items():
        st.session_state.setdefault(k, v)

    data_dir = PROJECT_ROOT / "data"
    default_csv = data_dir / "ga4_public_daily.csv"
    csv_files = sorted(data_dir.glob("*.csv"))
    path_options = [str(p) for p in csv_files] or [str(default_csv)]

    with st.sidebar:
        st.markdown("### Data")
        uploaded = st.file_uploader("Upload CSV", type=["csv"], help="GA4-style daily CSV (date + KPIs). Uses same loader as disk files.")
        selected_path = st.selectbox("Or choose dataset on disk", path_options, index=0)

        st.markdown("### Analysis")
        base_metric = st.selectbox("KPI", ["revenue", "conversion_rate", "churn", "cac"], index=0)
        sensitivity_key = st.selectbox(
            "Sensitivity",
            ["standard", "balanced", "sensitive"],
            index=1,
            format_func=lambda k: {"standard": "Standard", "balanced": "Balanced", "sensitive": "Sensitive"}[k],
        )
        window = st.slider("Rolling window", 7, 28, 14)
        human_approved = st.checkbox("Human approved (execute ranked actions)", value=False)

        st.markdown("### Dimensions")
        st.caption("Overrides which column is monitored when not “All” (region → segment → tier priority).")

    # Load base dataframe (sidebar needs dimension lists — load lightweight)
    df_base: pd.DataFrame | None = None
    if uploaded is not None:
        raw = uploaded.getvalue()
        sig = hashlib.sha256(raw).hexdigest()[:24]
        try:
            df_base = _load_uploaded_df(raw)
            if st.session_state.get("_last_upload_sig") != sig:
                st.session_state["_last_upload_sig"] = sig
                _append_log(f"Loaded uploaded CSV ({len(df_base)} rows).")
        except Exception as e:
            st.sidebar.error(f"Upload parse error: {e}")
    else:
        p = Path(selected_path)
        if p.is_file():
            mtime = p.stat().st_mtime
            df_base = _cached_load_csv(str(p), mtime)
        else:
            st.error(f"Dataset not found: {selected_path}")
            return

    if df_base is None or df_base.empty:
        st.warning("No data loaded.")
        return

    dmin = pd.Timestamp(df_base["date"].min()).normalize()
    dmax = pd.Timestamp(df_base["date"].max()).normalize()
    with st.sidebar:
        dr = st.slider(
            "Date range",
            min_value=dmin.to_pydatetime(),
            max_value=dmax.to_pydatetime(),
            value=(dmin.to_pydatetime(), dmax.to_pydatetime()),
            format="YYYY-MM-DD",
        )
        regions = ["All"] + _dim_suffixes(df_base, "rev_region_")
        segments = ["All"] + _dim_suffixes(df_base, "rev_customer_segment_")
        tiers = ["All"] + _dim_suffixes(df_base, "rev_product_tier_")
        region_sel = st.selectbox("Region", regions, index=0)
        segment_sel = st.selectbox("Customer segment", segments, index=0)
        tier_sel = st.selectbox("Product tier", tiers, index=0)

        show_anomalies = st.toggle("Show anomalies on charts", value=True)
        st.divider()
        run_clicked = st.button("Run Analysis", type="primary", width="stretch")

    df_f = _filter_date_range(df_base, dr[0], dr[1])
    metric_eff = _effective_metric_col(df_base, base_metric, region_sel, segment_sel, tier_sel)
    if metric_eff not in df_f.columns:
        st.error(f"Metric column `{metric_eff}` missing after filters.")
        return

    if run_clicked:
        with st.spinner("Running pipeline…"):
            t0 = time.perf_counter()
            det = detection_sensitivity(sensitivity_key)
            result = run_pipeline(
                df_f,
                metric_col=metric_eff,
                rolling_window=int(window),
                human_approved=human_approved,
                detection=det,
            )
            elapsed = (time.perf_counter() - t0) * 1000.0
            st.session_state["traces"] = result.rows
            st.session_state["df_run"] = df_f
            st.session_state["metric_effective"] = metric_eff
            st.session_state["window"] = window
            anom_n = sum(1 for r in result.rows if r.get("is_anomaly"))
            _append_log(
                f"Pipeline finished in {elapsed:.1f} ms · rows={len(df_f)} · metric={metric_eff} · anomalies={anom_n}"
            )
            try:
                ev = run_evaluation(
                    df_f,
                    mode="inject",
                    metric_col=metric_eff,
                    rolling_window=int(window),
                    seed=42,
                    detection=det,
                )
                st.session_state["eval_report"] = ev
                st.session_state["eval_table"] = evaluation_table(ev)
                lat = ev.get("system", {}).get("per_day_processing_ms", {})
                _append_log(
                    f"Evaluation (inject) · p50 latency ≈ {lat.get('p50_ms', 'n/a')} ms/day"
                )
            except Exception as e:
                st.session_state["eval_report"] = None
                st.session_state["eval_table"] = None
                _append_log(f"Evaluation skipped/failed: {e}")

    traces = st.session_state.get("traces")
    df_run = st.session_state.get("df_run")
    metric_run = st.session_state.get("metric_effective") or metric_eff

    if not traces or df_run is None:
        st.info("Configure the sidebar and click **Run Analysis** to execute the pipeline and populate all tabs.")
        return

    # Focus day (for RCA / explanation)
    labels = []
    for t in traces:
        d = t.get("date") or ""
        try:
            human = pd.Timestamp(d).strftime("%b %d, %Y")
        except Exception:
            human = str(d)[:10]
        tag = "Anomaly" if t.get("is_anomaly") else "Normal"
        labels.append(f"{human} · {tag}")
    anom_idx = [i for i, t in enumerate(traces) if t.get("is_anomaly")]
    default_i = anom_idx[-1] if anom_idx else len(traces) - 1

    tab1, tab2, tab3, tab4 = st.tabs(["Overview", "Anomalies", "Evaluation", "Logs"])

    confs = [float(t.get("confidence") or 0.0) for t in traces]
    avg_conf = sum(confs) / max(len(confs), 1)
    tot_rev = float(pd.to_numeric(df_run.get("revenue", pd.Series([0.0])), errors="coerce").fillna(0.0).sum())
    anom_count = sum(1 for t in traces if t.get("is_anomaly"))

    with tab1:
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Total revenue (window)", f"${tot_rev:,.0f}" if tot_rev >= 1000 else f"{tot_rev:,.2f}")
        c2.metric("Anomalies detected", anom_count, delta=None)
        c3.metric("Avg. confidence", f"{avg_conf * 100:.1f}%")
        c4.metric("Active agents", "6", help="Monitoring, Anomaly, RCA, Decision, Explanation, Controller")

        win_run = int(st.session_state.get("window") or 14)
        opt_c1, opt_c2, opt_c3 = st.columns([1.1, 1, 1])
        with opt_c1:
            viz_score_min = st.slider(
                "Chart: min anomaly score (markers)",
                min_value=0.0,
                max_value=4.0,
                value=0.0,
                step=0.05,
                help="Only pipeline-flagged days with score ≥ this value get red markers.",
            )
        with opt_c2:
            show_fc = st.toggle("Show 7-day forecast", value=True)
        with opt_c3:
            sev_mode = st.radio(
                "Severity histogram",
                ["All days", "Flagged only"],
                horizontal=True,
                label_visibility="visible",
            )

        st.plotly_chart(
            _plotly_kpi_trend_forecast_combo(
                df_run,
                metric_run,
                traces,
                rolling_window=win_run,
                show_anomalies=show_anomalies,
                viz_score_min=viz_score_min,
                show_forecast=show_fc,
            ),
            width="stretch",
        )
        st.plotly_chart(
            _plotly_anomaly_severity_distribution(
                traces,
                flagged_only=(sev_mode == "Flagged only"),
                show_kde=True,
            ),
            width="stretch",
        )

        st.download_button(
            label="Download report (traces JSON)",
            data=json.dumps(traces, default=str, indent=2),
            file_name="edi_traces_report.json",
            mime="application/json",
        )

    with tab2:
        st.plotly_chart(
            _plotly_anomaly_scores(traces, df_run, metric_run),
            width="stretch",
        )
        dkey = pd.to_datetime(df_run["date"]).dt.normalize()
        rows_tbl = []
        for t in traces:
            if not t.get("is_anomaly"):
                continue
            dn = pd.Timestamp(t.get("date")).normalize()
            sub = df_run.loc[dkey == dn, metric_run]
            val = float(pd.to_numeric(sub, errors="coerce").iloc[0]) if len(sub) else None
            rows_tbl.append(
                {
                    "date": str(t.get("date"))[:10],
                    "metric": metric_run,
                    "value": val,
                    "anomaly_score": t.get("anomaly_score"),
                    "confidence": t.get("confidence"),
                }
            )
        st.markdown("#### Flagged days")
        st.dataframe(pd.DataFrame(rows_tbl), width="stretch", hide_index=True)

        st.markdown("#### Inspect day (RCA & actions)")
        day_idx = st.selectbox(
            "Day",
            range(len(traces)),
            index=min(default_i, len(traces) - 1),
            format_func=lambda i: labels[i],
            key="inspect_day_tab2",
        )
        focus = traces[int(day_idx)]
        rc_rows = _normalize_rc_rows(focus)
        st.plotly_chart(_plotly_rca_bars(rc_rows), width="stretch")

        rc_df = pd.DataFrame(focus.get("root_causes_ranked") or [])
        st.dataframe(rc_df, width="stretch", hide_index=True)
        ra_df = pd.DataFrame(focus.get("ranked_actions") or [])
        st.dataframe(ra_df, width="stretch", hide_index=True)
        st.markdown("**Explanation**")
        st.code(focus.get("explanation_text") or "", language=None)

    with tab3:
        et = st.session_state.get("eval_table")
        rep = st.session_state.get("eval_report")
        if et is None or rep is None:
            st.warning("No evaluation available. Click **Run Analysis** again.")
        else:
            st.caption(
                "Inject mode marks **ground-truth** anomaly days via synthetic revenue spikes. "
                "**Agentic detector** uses the same **sensitivity** you picked in the sidebar. "
                "Baselines use fixed rules (often stricter) and may show 0 even when the agent fires."
            )
            sub = et[et["system"] == "agentic_system"]
            if not sub.empty:
                row = sub.iloc[0].to_dict()
                e1, e2, e3, e4 = st.columns(4)
                e1.metric("Precision", f"{float(row.get('precision') or 0):.3f}")
                e2.metric("Recall", f"{float(row.get('recall') or 0):.3f}")
                e3.metric("F1", f"{float(row.get('f1') or 0):.3f}")
                lat = rep.get("system", {}).get("per_day_processing_ms", {})
                e4.metric("Latency p50 (ms/day)", f"{float(lat.get('p50_ms', 0) or 0):.2f}")
                st.plotly_chart(_plotly_eval_bars(row), width="stretch")
            st.markdown("#### Full comparison table")
            st.dataframe(
                et,
                width="stretch",
                hide_index=True,
                column_config=_eval_column_config(),
            )

    with tab4:
        log_text = "\n".join(st.session_state.get("log_lines") or [])
        st.code(log_text or "(no logs yet)", language=None)
        merged = _merge_traces_to_df(df_run, traces)
        st.download_button(
            "Export CSV (data + anomaly flags)",
            data=merged.to_csv(index=False).encode("utf-8"),
            file_name="edi_export_with_flags.csv",
            mime="text/csv",
        )


if __name__ == "__main__":
    main()
