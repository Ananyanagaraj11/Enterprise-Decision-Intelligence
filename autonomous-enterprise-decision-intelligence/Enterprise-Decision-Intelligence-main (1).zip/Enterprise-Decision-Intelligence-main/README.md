# Enterprise Decision Intelligence (EDI)

**CIS-600** course project: daily e-commerce-style metrics → rolling baselines → anomaly detection → dimension attribution → ranked actions from a fixed playbook → explanation text. Implemented as a **central controller** plus **agents** with shared state (core math is not LLM-generated).

## What it does

1. **Monitoring** — Rolling mean / volatility on a chosen metric.  
2. **Anomaly detection** — Deviation vs baseline and confidence.  
3. **Attribution** — Current vs baseline per slice when `rev_region_*` / `rev_channel_*` (and related) columns exist.  
4. **Ranking** — Actions from `enterprise_decision_intel/config.py` scored by impact, risk, cost, plus small context boosts.  
5. **Explanation** — Template (optional LLM if API env vars are set).

## Data

Sample **GA4** CSV is included; larger exports from BigQuery are gitignored—recreate with:

| Script | Default output |
|--------|----------------|
| `scripts/fetch_ga4_bigquery.py` | `data/ga4_public_daily.csv` |
| `scripts/fetch_thelook_bigquery.py` | `data/thelook_ecommerce_daily.csv` |

## Setup

```bash
cd /path/to/Project
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

Optional BigQuery: `pip install -r requirements_fetch.txt`, `gcloud auth application-default login`, then run the fetch scripts above.

**CLI**

```bash
python3 run.py --csv data/ga4_public_daily.csv
python3 run.py --csv data/thelook_ecommerce_daily.csv --metric revenue --json
```

**Web UI (Django)**

```bash
pip install -r requirements_django.txt
cd web_edi && python3 manage.py runserver
```

Open [http://127.0.0.1:8000/](http://127.0.0.1:8000/). CSV paths in the UI are relative to the **project root** (parent of `web_edi/`).

Tabs (**Overview**, **Charts**, **Evaluation**, **Insights**) share one GET query string per run; **Settings** holds dataset and detection options. Templates live under `web_edi/core/templates/ui/`.

| Path | URL name | Role |
|------|----------|------|
| `/` | `home` | Overview, KPIs, links |
| `/charts/` | `charts` | Trend + \|z\| charts |
| `/evaluation/` | `evaluation` | Inject eval, F1/PR, tables |
| `/insights/` | `insights` | Root causes, actions |
| `/settings/` | `settings` | Filters and apply |
| `/download/traces.json` | `download_traces` | JSON traces |
| `/download/export.csv` | `download_export` | CSV + flags |

**Backend:** `core/views.py` → `core.services.build_context` (pipeline + eval). **Query parsing:** `core/query_params.py` (`parse_query_params`, `enrich_page_context`). Optional query keys include `viz_min`, `forecast`, `sev`, `multi_seed` (defaults if omitted; `multi_seed` for paired tests can be appended manually, e.g. `&multi_seed=10`).

**Performance on long series:** cost scales with **number of days**; narrow dates in Settings. Env: **`EDI_MAX_ROWS`** (cap trailing rows), **`EDI_CACHE_TTL`** (seconds to cache identical requests; `0` = off). Legacy names `EDI_DASHBOARD_*` still work where noted in code.

**Optional Streamlit:** `pip install -r requirements_dashboard.txt` → `streamlit run dashboard/app.py`

**CLI eval:** `python3 scripts/evaluate.py --help`

## Layout

```
enterprise_decision_intel/   # Package: config, pipeline, agents, evaluation
web_edi/                     # Django app + templates/ui/
scripts/                     # Fetch + evaluate
run.py                       # CLI
```

## Requirements

Python **3.10+** recommended. BigQuery scripts need **Google Cloud** application-default credentials.

## Course / deployment

Academic use. Before any public host: change `SECRET_KEY`, `DEBUG`, `ALLOWED_HOSTS`. Course PDFs are not tracked (see `.gitignore`).

## GitHub

```bash
gh auth login
cd /path/to/Project
gh repo create enterprise-decision-intelligence --public --source=. --remote=origin --push
```

Or create an empty repo on GitHub and `git remote add origin …` then `git push -u origin main`.
