from __future__ import annotations

import os
from copy import deepcopy

from django.core.cache import cache
from django.http import HttpRequest, HttpResponse, HttpResponseBadRequest
from django.shortcuts import render

from core.query_params import cache_key_for_request, enrich_page_context, parse_query_params
from core.services import PROJECT_ROOT, build_context


def _cache_ttl() -> int:
    raw = os.environ.get("EDI_CACHE_TTL") or os.environ.get("EDI_DASHBOARD_CACHE_TTL", "300")
    try:
        return int(raw)
    except ValueError:
        return 300


def _build_context_core(request: HttpRequest) -> tuple[dict | None, HttpResponse | None]:
    p = parse_query_params(request)
    csv_path = (PROJECT_ROOT / p["csv_rel"]).resolve()
    if not csv_path.is_file():
        return None, render(
            request,
            "core/error.html",
            {
                "message": f"CSV not found: {csv_path}",
                "hint": "GA4 sample: python scripts/fetch_ga4_bigquery.py --out data/ga4_public_daily.csv  |  "
                "Richer e-commerce: python scripts/fetch_thelook_bigquery.py --out data/thelook_ecommerce_daily.csv",
            },
            status=404,
        )
    key = cache_key_for_request(p, csv_path)
    ttl = _cache_ttl()
    if ttl > 0:
        cached = cache.get(key)
        if cached is not None:
            ctx = deepcopy(cached)
            ctx["page"] = ""
            return ctx, None

    try:
        ctx = build_context(
            csv_path,
            metric=p["metric"],
            window=p["window"],
            run_eval=p["run_eval"],
            inject_events=p["inject_n"],
            seed=p["seed"],
            day_index=p["day_index"],
            sensitivity=p["sensitivity"],
            human_approved=p["human_approved"],
            date_start=p["date_start"],
            date_end=p["date_end"],
            region=p["region"],
            segment=p["segment"],
            tier=p["tier"],
            viz_min_score=p["viz_min_score"],
            show_forecast=p["show_forecast"],
            severity_flagged_only=p["severity_flagged_only"],
            multi_seed_n=p["multi_seed_n"],
        )
    except Exception as e:
        return None, HttpResponseBadRequest(str(e))
    enrich_page_context(ctx, p)
    if ttl > 0:
        cache.set(key, ctx, timeout=ttl)
    ctx["page"] = ""
    return ctx, None


def overview(request: HttpRequest) -> HttpResponse:
    ctx, err = _build_context_core(request)
    if err:
        return err
    assert ctx is not None
    ctx["page"] = "overview"
    return render(request, "ui/overview.html", ctx)


def charts(request: HttpRequest) -> HttpResponse:
    ctx, err = _build_context_core(request)
    if err:
        return err
    assert ctx is not None
    ctx["page"] = "charts"
    return render(request, "ui/charts.html", ctx)


def evaluation(request: HttpRequest) -> HttpResponse:
    ctx, err = _build_context_core(request)
    if err:
        return err
    assert ctx is not None
    ctx["page"] = "evaluation"
    return render(request, "ui/evaluation.html", ctx)


def insights(request: HttpRequest) -> HttpResponse:
    ctx, err = _build_context_core(request)
    if err:
        return err
    assert ctx is not None
    ctx["page"] = "insights"
    return render(request, "ui/insights.html", ctx)


def settings_page(request: HttpRequest) -> HttpResponse:
    ctx, err = _build_context_core(request)
    if err:
        return err
    assert ctx is not None
    ctx["page"] = "settings"
    return render(request, "ui/settings.html", ctx)


def download_traces_json(request: HttpRequest) -> HttpResponse:
    p = parse_query_params(request)
    csv_path = (PROJECT_ROOT / p["csv_rel"]).resolve()
    if not csv_path.is_file():
        return HttpResponseBadRequest("CSV not found")
    try:
        ctx = build_context(
            csv_path,
            metric=p["metric"],
            window=p["window"],
            run_eval=p["run_eval"],
            inject_events=p["inject_n"],
            seed=p["seed"],
            day_index=p["day_index"],
            sensitivity=p["sensitivity"],
            human_approved=p["human_approved"],
            date_start=p["date_start"],
            date_end=p["date_end"],
            region=p["region"],
            segment=p["segment"],
            tier=p["tier"],
            viz_min_score=p["viz_min_score"],
            show_forecast=p["show_forecast"],
            severity_flagged_only=p["severity_flagged_only"],
            multi_seed_n=p["multi_seed_n"],
        )
    except Exception as e:
        return HttpResponseBadRequest(str(e))
    resp = HttpResponse(ctx["traces_json"], content_type="application/json; charset=utf-8")
    resp["Content-Disposition"] = 'attachment; filename="edi_traces_report.json"'
    return resp


def download_export_csv(request: HttpRequest) -> HttpResponse:
    p = parse_query_params(request)
    csv_path = (PROJECT_ROOT / p["csv_rel"]).resolve()
    if not csv_path.is_file():
        return HttpResponseBadRequest("CSV not found")
    try:
        ctx = build_context(
            csv_path,
            metric=p["metric"],
            window=p["window"],
            run_eval=p["run_eval"],
            inject_events=p["inject_n"],
            seed=p["seed"],
            day_index=p["day_index"],
            sensitivity=p["sensitivity"],
            human_approved=p["human_approved"],
            date_start=p["date_start"],
            date_end=p["date_end"],
            region=p["region"],
            segment=p["segment"],
            tier=p["tier"],
            viz_min_score=p["viz_min_score"],
            show_forecast=p["show_forecast"],
            severity_flagged_only=p["severity_flagged_only"],
            multi_seed_n=p["multi_seed_n"],
        )
    except Exception as e:
        return HttpResponseBadRequest(str(e))
    resp = HttpResponse(ctx["export_csv"], content_type="text/csv; charset=utf-8")
    resp["Content-Disposition"] = 'attachment; filename="edi_export_with_flags.csv"'
    return resp
