from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

from django.http import HttpRequest


def cache_key_for_request(p: dict[str, Any], csv_path: Path) -> str:
    try:
        mtime = csv_path.stat().st_mtime
    except OSError:
        mtime = 0.0
    max_rows = os.environ.get("EDI_MAX_ROWS") or os.environ.get("EDI_DASHBOARD_MAX_ROWS", "")
    env_sig = "|".join([os.environ.get("EDI_LEARNED_BOOSTS", ""), max_rows])
    payload = {k: p[k] for k in sorted(p.keys())}
    payload["_csv"] = str(csv_path.resolve())
    payload["_mtime"] = mtime
    payload["_env"] = env_sig
    s = json.dumps(payload, sort_keys=True, default=str)
    return "edi_v1:" + hashlib.sha256(s.encode()).hexdigest()


def parse_query_params(request: HttpRequest) -> dict[str, Any]:
    csv_rel = request.GET.get("csv", "data/ga4_public_daily.csv")
    metric = request.GET.get("metric", "revenue")
    window = int(request.GET.get("window", "14"))
    run_eval = request.GET.get("eval", "1") not in ("0", "false", "False")
    inject_n = int(request.GET.get("inject", "8"))
    seed = int(request.GET.get("seed", "42"))
    day_raw = request.GET.get("day")
    day_index = int(day_raw) if day_raw is not None and str(day_raw).isdigit() else None

    sensitivity = request.GET.get("sensitivity", "balanced")
    if sensitivity not in ("standard", "balanced", "sensitive", "explorer"):
        sensitivity = "balanced"

    human_approved = request.GET.get("approve", "") in ("1", "true", "True", "on")

    date_start = request.GET.get("date_start") or None
    date_end = request.GET.get("date_end") or None

    region = request.GET.get("region", "All") or "All"
    segment = request.GET.get("segment", "All") or "All"
    tier = request.GET.get("tier", "All") or "All"

    try:
        viz_min_score = float(request.GET.get("viz_min", "0"))
    except ValueError:
        viz_min_score = 0.0
    show_forecast = request.GET.get("forecast", "1") not in ("0", "false", "False")
    severity_flagged_only = request.GET.get("sev", "all") == "flagged"

    raw_ms = request.GET.get("multi_seed")
    if raw_ms is None or str(raw_ms).strip() == "":
        multi_seed_n = 0
    else:
        try:
            multi_seed_n = int(float(str(raw_ms).strip()))
        except ValueError:
            multi_seed_n = 0
    multi_seed_n = max(0, min(50, multi_seed_n))

    return {
        "csv_rel": csv_rel,
        "metric": metric,
        "window": window,
        "run_eval": run_eval,
        "inject_n": inject_n,
        "seed": seed,
        "day_index": day_index,
        "sensitivity": sensitivity,
        "human_approved": human_approved,
        "date_start": date_start,
        "date_end": date_end,
        "region": region,
        "segment": segment,
        "tier": tier,
        "viz_min_score": viz_min_score,
        "show_forecast": show_forecast,
        "severity_flagged_only": severity_flagged_only,
        "multi_seed_n": multi_seed_n,
    }


def query_for_template(p: dict[str, Any]) -> dict[str, Any]:
    return {
        "csv": p["csv_rel"],
        "metric": p["metric"],
        "window": p["window"],
        "eval": "1" if p["run_eval"] else "0",
        "inject": p["inject_n"],
        "seed": p["seed"],
        "sensitivity": p["sensitivity"],
        "approve": "1" if p["human_approved"] else "0",
        "date_start": p["date_start"] or "",
        "date_end": p["date_end"] or "",
        "region": p["region"],
        "segment": p["segment"],
        "tier": p["tier"],
        "viz_min": str(p["viz_min_score"]),
        "forecast": "1" if p["show_forecast"] else "0",
        "sev": "flagged" if p["severity_flagged_only"] else "all",
        "multi_seed": str(p["multi_seed_n"]),
    }


def enrich_page_context(ctx: dict[str, Any], p: dict[str, Any]) -> None:
    qd = query_for_template(p)
    qd["day"] = str(ctx["pick_index"])
    ctx["query"] = qd
    ctx["query_hidden"] = [(k, str(v)) for k, v in qd.items() if k != "day"]
    ctx["multi_seed_n"] = p["multi_seed_n"]
    ctx["multi_seed_seed_last"] = (
        p["seed"] + max(0, p["multi_seed_n"] - 1) if p["multi_seed_n"] > 0 else p["seed"]
    )
    ctx["download_qs"] = urlencode({k: str(v) for k, v in qd.items() if str(v) != ""})
    ctx["nav_qs"] = ctx["download_qs"]

    dr = ""
    if p["date_start"] or p["date_end"]:
        dr = f"{p['date_start'] or '…'} → {p['date_end'] or '…'}"
    else:
        dr = "Full range"
    dim_bits: list[str] = []
    if p["region"] != "All":
        dim_bits.append(f"region={p['region']}")
    if p["segment"] != "All":
        dim_bits.append(f"segment={p['segment']}")
    if p["tier"] != "All":
        dim_bits.append(f"tier={p['tier']}")
    ctx["filter_chips"] = [
        ("Dataset", str(qd.get("csv", "")).replace("data/", "")),
        ("KPI (effective)", str(ctx.get("metric_label") or p["metric"])),
        ("Sensitivity", p["sensitivity"]),
        ("Rolling window", f'{p["window"]} days'),
        ("Eval", "Inject" if p["run_eval"] else "Raw"),
        ("Seed / inject", f'{p["seed"]} / {p["inject_n"]}'),
        ("Date range", dr),
        ("Dimensions", ", ".join(dim_bits) if dim_bits else "none (base KPI)"),
    ]
