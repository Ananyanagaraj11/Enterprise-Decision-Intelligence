from django.urls import path

from core import views

urlpatterns = [
    path("", views.overview, name="home"),
    path("charts/", views.charts, name="charts"),
    path("evaluation/", views.evaluation, name="evaluation"),
    path("insights/", views.insights, name="insights"),
    path("settings/", views.settings_page, name="settings"),
    path("download/traces.json", views.download_traces_json, name="download_traces"),
    path("download/export.csv", views.download_export_csv, name="download_export"),
]
