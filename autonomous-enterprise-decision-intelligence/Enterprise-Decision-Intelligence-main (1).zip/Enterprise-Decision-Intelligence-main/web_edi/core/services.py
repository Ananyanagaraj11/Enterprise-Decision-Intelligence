"""Build page context from GA4 CSV and the agent pipeline (charts, tables, traces)."""

from __future__ import annotations

import json
import math
import os
from dataclasses import replace
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from enterprise_decision_intel.config import DetectionConfig, detection_sensitivity
from enterprise_decision_intel.data_pipeline import load_ga4_style_csv
from enterprise_decision_intel.evaluation.injection import inject_controlled_anomalies
from enterprise_decision_intel.evaluation.multi_run_stats import run_multi_seed_study
from enterprise_decision_intel.evaluation.runner import evaluation_table, run_evaluation
from enterprise_decision_intel.pipeline import run_dataset_from_df

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def _load_learned_boosts_from_env() -> dict[str, float] | None:
    """Optional path from EDI_LEARNED_BOOSTS (JSON from scripts/fit_learned_boosts.py)."""
    raw = os.environ.get("EDI_LEARNED_BOOSTS", "").strip()
    if not raw:
        return None
    p = Path(raw)
    if not p.is_file():
        return None
    try:
        payload = json.loads(p.read_text(encoding="utf-8"))
        return {str(k): float(v) for k, v in (payload.get("learned_boosts") or {}).items()}
    except (OSError, ValueError, TypeError):
        return None


def _nan_to_none(v: Any) -> Any:
    """Pandas turns None in float columns into NaN; templates treat NaN as not None and print 'nan'."""
    if v is None:
        return None
    if isinstance(v, float) and math.isnan(v):
        return None
    return v


def _human_date(s: str | None) -> str:
    if not s:
        return "—"
    try:
        return pd.Timestamp(s).strftime("%b %d, %Y")
    except Exception:
        return str(s)[:10]


def _is_currency_metric(metric: str) -> bool:
    if metric in ("revenue", "aov"):
        return True
    return metric.startswith("rev_")


def _norm_series(s: pd.Series) -> list[float | None]:
    """Min–max normalize to [0, 1] for overlay charts (per-series)."""
    v = pd.to_numeric(s, errors="coerce")
    lo, hi = float(v.min()), float(v.max())
    if hi - lo < 1e-12:
        return [0.5 if pd.notna(x) else None for x in v]
    out: list[float | None] = []
    for x in v:
        if pd.isna(x):
            out.append(None)
        else:
            out.append((float(x) - lo) / (hi - lo))
    return out


def _fmt_num(x: Any, currency: bool = False) -> str:
    if x is None:
        return "—"
    try:
        v = float(x)
        if currency:
            return f"${v:,.0f}" if v >= 100 else f"${v:,.2f}"
        if abs(v) >= 1000:
            return f"{v:,.1f}"
        return f"{v:.2f}"
    except (TypeError, ValueError):
        return str(x)


def _dim_suffixes(df: pd.DataFrame, prefix: str) -> list[str]:
    return sorted({c.replace(prefix, "") for c in df.columns if c.startswith(prefix)})


def _effective_metric_col(
    df: pd.DataFrame,
    base_metric: str,
    region_sel: str,
    segment_sel: str,
    tier_sel: str,
) -> str:
    if region_sel != "All":
        c = f"rev_region_{region_sel}"
        if c in df.columns:
            return c
    if segment_sel != "All":
        c = f"rev_customer_segment_{segment_sel}"
        if c in df.columns:
            return c
    if tier_sel != "All":
        c = f"rev_product_tier_{tier_sel}"
        if c in df.columns:
            return c
    return base_metric


def _filter_date_range(df: pd.DataFrame, start: pd.Timestamp | None, end: pd.Timestamp | None) -> pd.DataFrame:
    if start is None and end is None:
        return df
    d = pd.to_datetime(df["date"])
    m = pd.Series(True, index=df.index)
    if start is not None:
        m &= d >= pd.Timestamp(start).normalize()
    if end is not None:
        m &= d <= pd.Timestamp(end).normalize()
    return df.loc[m].reset_index(drop=True)


def _simple_linear_forecast(dates: pd.Series, y: pd.Series, horizon: int = 7) -> tuple[pd.DatetimeIndex, list[float]]:
    y = pd.to_numeric(y, errors="coerce").ffill().fillna(0.0)
    n = min(28, len(y))
    if n < 3:
        return pd.DatetimeIndex([]), []
    ys = y.iloc[-n:].values.astype(float)
    xs = pd.to_datetime(dates.iloc[-n:]).map(pd.Timestamp.toordinal).values.astype(float)
    x_mean, y_mean = xs.mean(), ys.mean()
    denom = ((xs - x_mean) ** 2).sum()
    if denom < 1e-12:
        slope = 0.0
    else:
        slope = ((xs - x_mean) * (ys - y_mean)).sum() / denom
    intercept = y_mean - slope * x_mean
    last_d = pd.Timestamp(dates.iloc[-1]).normalize()
    future = pd.date_range(last_d + pd.Timedelta(days=1), periods=horizon, freq="D")
    preds = [float(intercept + slope * pd.Timestamp(d).toordinal()) for d in future]
    return future, preds


def _trace_lookup_by_date(traces: list[dict]) -> dict[pd.Timestamp, dict[str, Any]]:
    out: dict[pd.Timestamp, dict[str, Any]] = {}
    for t in traces:
        d = pd.Timestamp(t.get("date")).normalize()
        out[d] = {
            "is_anomaly": bool(t.get("is_anomaly")),
            "anomaly_score": t.get("anomaly_score"),
        }
    return out


def build_context(
    csv_path: Path,
    *,
    metric: str = "revenue",
    window: int = 14,
    run_eval: bool = True,
    inject_events: int = 8,
    seed: int = 42,
    day_index: int | None = None,
    sensitivity: str = "balanced",
    human_approved: bool = False,
    date_start: str | None = None,
    date_end: str | None = None,
    region: str = "All",
    segment: str = "All",
    tier: str = "All",
    viz_min_score: float = 0.0,
    show_forecast: bool = True,
    severity_flagged_only: bool = False,
    multi_seed_n: int = 0,
) -> dict[str, Any]:
    df_full = load_ga4_style_csv(csv_path)
    if metric not in df_full.columns:
        raise ValueError(f"Column {metric} not in CSV")

    ts_start = pd.Timestamp(date_start).normalize() if date_start else None
    ts_end = pd.Timestamp(date_end).normalize() if date_end else None
    df = _filter_date_range(df_full, ts_start, ts_end)
    if df.empty:
        raise ValueError("No rows in selected date range.")

    performance_note: str | None = None
    try:
        raw = os.environ.get("EDI_MAX_ROWS") or os.environ.get("EDI_DASHBOARD_MAX_ROWS", "0") or "0"
        max_rows_cap = int(raw)
    except ValueError:
        max_rows_cap = 0
    if max_rows_cap > 0 and len(df) > max_rows_cap:
        df = df.iloc[-max_rows_cap:].copy().reset_index(drop=True)
        performance_note = (
            f"Performance: using only the last {max_rows_cap:,} days (set env EDI_MAX_ROWS). "
            "Narrow the date range in Settings if you need a specific window."
        )

    metric_eff = _effective_metric_col(df_full, metric, region, segment, tier)
    if metric_eff not in df.columns:
        raise ValueError(f"Metric column `{metric_eff}` missing after filters.")

    learned = _load_learned_boosts_from_env()
    det = replace(detection_sensitivity(sensitivity), rolling_window=window)

    multi_seed_report: dict[str, Any] | None = None
    if run_eval and multi_seed_n >= 2:
        seeds_ms = [seed + i for i in range(multi_seed_n)]
        multi_seed_report = run_multi_seed_study(
            df,
            seeds=seeds_ms,
            inject_events=inject_events,
            metric_col=metric_eff,
            rolling_window=window,
            detection=det,
            learned_boosts=learned,
            human_approved=human_approved,
        )

    report: dict | None = None
    traces: list[dict] = []

    if run_eval:
        inj = inject_controlled_anomalies(df, inject_events, seed=seed)
        report = run_evaluation(
            df,
            mode="inject",
            injection=inj,
            metric_col=metric_eff,
            rolling_window=window,
            include_traces=True,
            learned_boosts=learned,
            detection=det,
            human_approved=human_approved,
        )
        traces = list(report.pop("traces", []) or [])
        df_plot = inj.df
    else:
        result = run_dataset_from_df(
            df,
            metric_col=metric_eff,
            rolling_window=window,
            learned_boosts=learned,
            detection=det,
            human_approved=human_approved,
        )
        traces = result.rows
        df_plot = df

    d = df_plot.sort_values("date").reset_index(drop=True)
    dates = pd.to_datetime(d["date"])
    y = d[metric_eff].astype(float)
    win = int(det.rolling_window)
    min_periods = max(3, max(2, win // 2))
    rm = y.rolling(win, min_periods=min_periods).mean()
    rstd = y.rolling(win, min_periods=min_periods).std()

    labels = [d.strftime("%b %d") for d in dates]
    values = [float(v) if pd.notna(v) else None for v in y]
    rolling = [float(v) if pd.notna(v) else None for v in rm]
    anom = [bool(traces[i].get("is_anomaly")) for i in range(len(traces))]

    z_scores: list[float | None] = []
    for i in range(len(y)):
        mu = rm.iloc[i]
        sig = rstd.iloc[i]
        xv = y.iloc[i]
        if pd.notna(mu) and pd.notna(sig) and pd.notna(xv) and float(sig) > 1e-9:
            z_scores.append(abs(float(xv) - float(mu)) / float(sig))
        else:
            z_scores.append(None)

    anom_indices = [i for i, t in enumerate(traces) if t.get("is_anomaly")]
    if day_index is not None and traces and 0 <= day_index < len(traces):
        pick_i = day_index
    else:
        pick_i = anom_indices[-1] if anom_indices else (len(traces) - 1 if traces else 0)
    sel = traces[pick_i] if traces else {}

    ml = metric_eff.replace("_", " ")
    summary_html = ""
    if sel:
        is_anom = bool(sel.get("is_anomaly"))
        if is_anom:
            summary_html = (
                f"<p class='text-slate-700 leading-relaxed'>On <strong>{_human_date(str(sel.get('date')))}</strong>, "
                f"<strong>{ml}</strong> was <strong>{_fmt_num(sel.get('current_value'), _is_currency_metric(metric_eff))}</strong> — "
                f"outside the usual band (baseline near <strong>{_fmt_num(sel.get('rolling_mean'), _is_currency_metric(metric_eff))}</strong>). "
                f"Flagged as an <strong>anomaly</strong> with confidence <strong>{_fmt_num(sel.get('confidence'))}</strong>.</p>"
            )
        else:
            summary_html = (
                f"<p class='text-slate-700 leading-relaxed'>On <strong>{_human_date(str(sel.get('date')))}</strong>, "
                f"<strong>{ml}</strong> matches the rolling baseline — <strong>no root-cause step</strong> on normal days.</p>"
            )

    detection = report.get("detection", {}) if report else {}
    if multi_seed_report is not None:
        s = multi_seed_report["summary"]
        f1_chart = {
            "labels": ["Agent", "Static bounds", "Z-only", "Manual %Δ"],
            "values": [
                s["agentic_f1"]["mean"],
                s["baseline_1_f1"]["mean"],
                s["baseline_2_f1"]["mean"],
                s["baseline_3_f1"]["mean"],
            ],
            "stdevs": [
                s["agentic_f1"]["stdev"],
                s["baseline_1_f1"]["stdev"],
                s["baseline_2_f1"]["stdev"],
                s["baseline_3_f1"]["stdev"],
            ],
            "multi": True,
        }
        pr_chart = {
            "labels": ["Agent", "B1", "B2", "B3"],
            "datasets": [
                {
                    "label": "Precision",
                    "data": [
                        s["agentic_precision"]["mean"],
                        s["baseline_1_precision"]["mean"],
                        s["baseline_2_precision"]["mean"],
                        s["baseline_3_precision"]["mean"],
                    ],
                    "stdevs": [
                        s["agentic_precision"]["stdev"],
                        s["baseline_1_precision"]["stdev"],
                        s["baseline_2_precision"]["stdev"],
                        s["baseline_3_precision"]["stdev"],
                    ],
                },
                {
                    "label": "Recall",
                    "data": [
                        s["agentic_recall"]["mean"],
                        s["baseline_1_recall"]["mean"],
                        s["baseline_2_recall"]["mean"],
                        s["baseline_3_recall"]["mean"],
                    ],
                    "stdevs": [
                        s["agentic_recall"]["stdev"],
                        s["baseline_1_recall"]["stdev"],
                        s["baseline_2_recall"]["stdev"],
                        s["baseline_3_recall"]["stdev"],
                    ],
                },
            ],
            "multi": True,
        }
    else:
        f1_chart = {
            "labels": ["Agent", "Static bounds", "Z-only", "Manual %Δ"],
            "values": [
                (detection.get("agentic_system") or {}).get("f1", 0),
                (detection.get("baseline_1_static_threshold") or {}).get("f1", 0),
                (detection.get("baseline_2_z_only") or {}).get("f1", 0),
                (detection.get("baseline_3_manual_script") or {}).get("f1", 0),
            ],
            "multi": False,
        }
        pr_chart = {
            "labels": ["Agent", "B1", "B2", "B3"],
            "datasets": [
                {
                    "label": "Precision",
                    "data": [
                        (detection.get("agentic_system") or {}).get("precision", 0),
                        (detection.get("baseline_1_static_threshold") or {}).get("precision", 0),
                        (detection.get("baseline_2_z_only") or {}).get("precision", 0),
                        (detection.get("baseline_3_manual_script") or {}).get("precision", 0),
                    ],
                },
                {
                    "label": "Recall",
                    "data": [
                        (detection.get("agentic_system") or {}).get("recall", 0),
                        (detection.get("baseline_1_static_threshold") or {}).get("recall", 0),
                        (detection.get("baseline_2_z_only") or {}).get("recall", 0),
                        (detection.get("baseline_3_manual_script") or {}).get("recall", 0),
                    ],
                },
            ],
            "multi": False,
        }

    day_options = []
    for i, t in enumerate(traces):
        day_options.append(
            {
                "i": i,
                "label": f"{_human_date(str(t.get('date')))} · {'Anomaly' if t.get('is_anomaly') else 'Normal'}",
                "is_anomaly": bool(t.get("is_anomaly")),
            }
        )

    chart_norm: str | None = None
    norm_sets: list[dict[str, Any]] = []
    if "revenue" in d.columns:
        norm_sets.append({"label": "Revenue (normalized)", "data": _norm_series(d["revenue"])})
    if "purchases" in d.columns:
        norm_sets.append({"label": "Orders (normalized)", "data": _norm_series(d["purchases"])})
    if "active_users" in d.columns:
        norm_sets.append({"label": "Active buyers (normalized)", "data": _norm_series(d["active_users"])})
    if "line_items" in d.columns:
        norm_sets.append({"label": "Line items (normalized)", "data": _norm_series(d["line_items"])})
    if len(norm_sets) >= 2:
        chart_norm = json.dumps({"labels": labels, "datasets": norm_sets})

    confs = [float(t.get("confidence") or 0.0) for t in traces]
    avg_conf = sum(confs) / max(len(confs), 1)
    if "revenue" in d.columns:
        tot_rev = float(pd.to_numeric(d["revenue"], errors="coerce").fillna(0.0).sum())
    else:
        tot_rev = float(pd.to_numeric(y, errors="coerce").fillna(0.0).sum())

    eval_rows: list[dict[str, Any]] = []
    eval_columns: list[str] = []
    latency_p50: float | None = None
    if report:
        et = evaluation_table(report)
        eval_rows = [
            {k: _nan_to_none(v) for k, v in row.items()} for row in et.to_dict(orient="records")
        ]
        eval_columns = list(et.columns)
        lat = report.get("system", {}).get("per_day_processing_ms", {})
        if lat.get("p50_ms") is not None:
            latency_p50 = float(lat["p50_ms"])

    upper_list: list[float | None] = []
    lower_list: list[float | None] = []
    for i in range(len(y)):
        mu_i, sig_i = rm.iloc[i], rstd.iloc[i]
        if pd.notna(mu_i) and pd.notna(sig_i):
            upper_list.append(float(mu_i + sig_i))
            lower_list.append(float(mu_i - sig_i))
        else:
            upper_list.append(None)
            lower_list.append(None)

    lookup_td = _trace_lookup_by_date(traces)
    anom_markers: list[float | None] = []
    for i in range(len(dates)):
        dtn = pd.Timestamp(dates.iloc[i]).normalize()
        info = lookup_td.get(dtn) or {}
        yv = float(y.iloc[i]) if pd.notna(y.iloc[i]) else None
        if not info.get("is_anomaly") or yv is None:
            anom_markers.append(None)
            continue
        sc = float(info.get("anomaly_score") or 0.0)
        if sc < float(viz_min_score):
            anom_markers.append(None)
        else:
            anom_markers.append(yv)

    fut, pred = _simple_linear_forecast(dates, y, horizon=7)
    show_fc = bool(show_forecast and len(fut) > 0)
    if show_fc:
        ext_labels = labels + [pd.Timestamp(x).strftime("%b %d") for x in fut]
        pad = len(fut)
        vals_ext = values + [None] * pad
        rolling_ext = rolling + [None] * pad
        upper_ext = upper_list + [None] * pad
        lower_ext = lower_list + [None] * pad
        forecast_ext = [None] * len(values) + [float(x) for x in pred]
    else:
        ext_labels = labels
        vals_ext = values
        rolling_ext = rolling
        upper_ext = upper_list
        lower_ext = lower_list
        forecast_ext = [None] * len(values)

    chart_combo = json.dumps(
        {
            "labels": ext_labels,
            "values": vals_ext,
            "rolling": rolling_ext,
            "upper": upper_ext,
            "lower": lower_ext,
            "forecast": forecast_ext,
            "anomaly_markers": anom_markers + [None] * (len(ext_labels) - len(anom_markers)),
        }
    )

    scores: list[float] = []
    for t in traces:
        if severity_flagged_only and not t.get("is_anomaly"):
            continue
        if t.get("anomaly_score") is None:
            continue
        scores.append(float(t["anomaly_score"]))
    if not scores:
        scores = [0.0]
    nb = int(min(28, max(14, max(1, len(scores) // 2))))
    counts, edges = np.histogram(np.asarray(scores, dtype=float), bins=nb)
    centers = ((edges[:-1] + edges[1:]) / 2.0).tolist()
    chart_severity = json.dumps({"centers": centers, "counts": counts.tolist()})

    ascores = [float(t.get("anomaly_score") or 0.0) for t in traces]
    aflag = [bool(t.get("is_anomaly")) for t in traces]
    chart_anomaly_score = json.dumps({"labels": labels, "scores": ascores, "flagged": aflag})

    rc_list = sel.get("root_causes") or sel.get("root_causes_ranked") or []
    rlab = [f"{r.get('dimension', '—')}:{r.get('value', '—')}" for r in rc_list if isinstance(r, dict)]
    rval: list[float] = []
    for r in rc_list:
        if not isinstance(r, dict):
            rval.append(0.0)
            continue
        v = r.get("contribution_pct")
        if v is None:
            v = r.get("pct") or r.get("score") or 0.0
        rval.append(float(v))
    chart_rca = json.dumps({"labels": rlab, "values": rval})

    trows = []
    for t in traces:
        trows.append(
            {
                "date": pd.Timestamp(t.get("date")).normalize(),
                "is_anomaly": bool(t.get("is_anomaly")),
                "anomaly_score": t.get("anomaly_score"),
                "confidence": t.get("confidence"),
                "execution_status": t.get("execution_status"),
            }
        )
    tdf = pd.DataFrame(trows)
    out_m = d.copy()
    out_m["date"] = pd.to_datetime(out_m["date"]).dt.normalize()
    merged_export = out_m.merge(tdf, on="date", how="left")
    export_csv = merged_export.to_csv(index=False)

    regions_opt = ["All"] + _dim_suffixes(df_full, "rev_region_")
    segments_opt = ["All"] + _dim_suffixes(df_full, "rev_customer_segment_")
    tiers_opt = ["All"] + _dim_suffixes(df_full, "rev_product_tier_")
    dmin = pd.Timestamp(df_full["date"].min()).normalize()
    dmax = pd.Timestamp(df_full["date"].max()).normalize()

    metric_label_eff = metric_eff.replace("_", " ").title()
    kpi_is_currency = _is_currency_metric(metric_eff)

    return {
        "metric_label": metric_label_eff,
        "metric": metric,
        "metric_eff": metric_eff,
        "metric_label_eff": metric_label_eff,
        "csv_name": csv_path.name,
        "n_days": len(d),
        "n_anomalies": sum(anom),
        "summary_html": summary_html,
        "selected": sel,
        "selected_day_human": _human_date(str(sel.get("date"))),
        "pick_index": pick_i,
        "day_options": day_options,
        "chart_line": json.dumps(
            {
                "labels": labels,
                "values": values,
                "rolling": rolling,
                "anomalies": anom,
                "z": z_scores,
            }
        ),
        "chart_z": json.dumps({"labels": labels, "z": z_scores}),
        "chart_f1": json.dumps(f1_chart),
        "chart_pr": json.dumps(pr_chart),
        "chart_norm": chart_norm,
        "chart_combo": chart_combo,
        "chart_severity": chart_severity,
        "chart_anomaly_score": chart_anomaly_score,
        "chart_rca": chart_rca,
        "root_causes": rc_list,
        "ranked_actions": sel.get("ranked_actions") or [],
        "explanation": sel.get("explanation_text") or "",
        "report": report,
        "detection": detection,
        "focus_is_anomaly": bool(sel.get("is_anomaly")),
        "focus_confidence": sel.get("confidence"),
        "avg_confidence": avg_conf,
        "total_revenue_window": tot_rev,
        "eval_rows": eval_rows,
        "eval_columns": eval_columns,
        "latency_p50": latency_p50,
        "traces_json": json.dumps(traces, default=str, indent=2),
        "export_csv": export_csv,
        "regions_opt": regions_opt,
        "segments_opt": segments_opt,
        "tiers_opt": tiers_opt,
        "date_min": dmin.strftime("%Y-%m-%d"),
        "date_max": dmax.strftime("%Y-%m-%d"),
        "kpi_is_currency": kpi_is_currency,
        "multi_seed_report": multi_seed_report,
        "performance_note": performance_note,
    }
