#!/usr/bin/env python3
"""Fit per-action learned_boosts from inject-mode runs (writes JSON for run.py --learned-boosts)."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from enterprise_decision_intel.data_pipeline import load_ga4_style_csv
from enterprise_decision_intel.learning.injection_calibration import fit_learned_boosts


def main() -> None:
    p = argparse.ArgumentParser(description="Fit injection-calibrated action boosts")
    p.add_argument("--csv", required=True, help="Daily GA4-style CSV")
    p.add_argument("--n-seeds", type=int, default=8, help="Number of seeds starting at --base-seed")
    p.add_argument("--base-seed", type=int, default=42)
    p.add_argument("--inject-events", type=int, default=10)
    p.add_argument("--metric", default="revenue")
    p.add_argument("--out", type=Path, default=ROOT / "data" / "learned_action_boosts.json")
    args = p.parse_args()

    df = load_ga4_style_csv(args.csv)
    seeds = [args.base_seed + i for i in range(args.n_seeds)]
    out = fit_learned_boosts(
        df,
        seeds,
        inject_events=args.inject_events,
        metric_col=args.metric,
    )
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))
    print(f"\nWrote {args.out}", file=sys.stderr)
    print("Use: python3 run.py --csv ... --learned-boosts " + str(args.out), file=sys.stderr)


if __name__ == "__main__":
    main()
