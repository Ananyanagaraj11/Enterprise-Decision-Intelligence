"""Multi-seed inject-mode evaluation with paired tests (exploratory; small-N caveat)."""

from __future__ import annotations

import statistics
from typing import Any

import pandas as pd
from scipy.stats import ttest_rel, wilcoxon

from enterprise_decision_intel.config import DetectionConfig
from enterprise_decision_intel.evaluation.runner import run_evaluation


def _safe_wilcoxon(a: list[float], b: list[float]) -> dict[str, float | None]:
    if len(a) < 5:
        return {"statistic": None, "p_value": None, "note": "Wilcoxon needs n>=5 paired runs"}
    try:
        stat, p = wilcoxon(a, b, zero_method="wilcox", alternative="two-sided")
        return {"statistic": float(stat), "p_value": float(p), "note": None}
    except Exception as e:
        return {"statistic": None, "p_value": None, "note": str(e)}


def run_multi_seed_study(
    df: pd.DataFrame,
    *,
    seeds: list[int],
    inject_events: int = 10,
    metric_col: str = "revenue",
    rolling_window: int = 14,
    detection: DetectionConfig | None = None,
    learned_boosts: dict[str, float] | None = None,
    human_approved: bool = False,
) -> dict[str, Any]:
    """
    Repeat inject-mode evaluation across independent RNG seeds (different injection placements).

    Paired tests compare matched runs (same seeds) for agent F1 vs each baseline F1.
    With few runs, p-values are exploratory — use for reporting ranges and direction, not definitive NHST.
    """
    if len(seeds) < 2:
        raise ValueError("Provide at least 2 seeds for variability / paired tests")

    det = detection or DetectionConfig(rolling_window=rolling_window)

    agent_f1: list[float] = []
    agent_prec: list[float] = []
    agent_rec: list[float] = []
    b1_f1: list[float] = []
    b2_f1: list[float] = []
    b3_f1: list[float] = []
    b1_prec: list[float] = []
    b1_rec: list[float] = []
    b2_prec: list[float] = []
    b2_rec: list[float] = []
    b3_prec: list[float] = []
    b3_rec: list[float] = []
    rc1: list[float] = []
    rc3: list[float] = []

    per_seed: list[dict[str, Any]] = []

    for seed in seeds:
        rep = run_evaluation(
            df,
            mode="inject",
            inject_events=inject_events,
            seed=seed,
            metric_col=metric_col,
            rolling_window=rolling_window,
            detection=det,
            learned_boosts=learned_boosts,
            human_approved=human_approved,
        )
        per_seed.append(
            {
                "seed": seed,
                "agent_f1": float(rep["detection"]["agentic_system"]["f1"]),
                "baseline_1_f1": float(rep["detection"]["baseline_1_static_threshold"]["f1"]),
                "rc_top1": float(rep["root_cause"]["top1"]["accuracy"]),
            }
        )
        da = rep["detection"]["agentic_system"]
        agent_f1.append(float(da["f1"]))
        agent_prec.append(float(da["precision"]))
        agent_rec.append(float(da["recall"]))
        b1_f1.append(float(rep["detection"]["baseline_1_static_threshold"]["f1"]))
        b2_f1.append(float(rep["detection"]["baseline_2_z_only"]["f1"]))
        b3_f1.append(float(rep["detection"]["baseline_3_manual_script"]["f1"]))
        b1_prec.append(float(rep["detection"]["baseline_1_static_threshold"]["precision"]))
        b1_rec.append(float(rep["detection"]["baseline_1_static_threshold"]["recall"]))
        b2_prec.append(float(rep["detection"]["baseline_2_z_only"]["precision"]))
        b2_rec.append(float(rep["detection"]["baseline_2_z_only"]["recall"]))
        b3_prec.append(float(rep["detection"]["baseline_3_manual_script"]["precision"]))
        b3_rec.append(float(rep["detection"]["baseline_3_manual_script"]["recall"]))
        rc1.append(float(rep["root_cause"]["top1"]["accuracy"]))
        rc3.append(float(rep["root_cause"]["top3"]["accuracy"]))

    def _summ(xs: list[float]) -> dict[str, float]:
        return {
            "mean": float(statistics.mean(xs)),
            "stdev": float(statistics.stdev(xs)) if len(xs) > 1 else 0.0,
            "min": float(min(xs)),
            "max": float(max(xs)),
            "n": float(len(xs)),
        }

    def _paired(agent: list[float], base: list[float], name: str) -> dict[str, Any]:
        t_stat, p_t = ttest_rel(agent, base)
        if t_stat != t_stat:
            t_stat = 0.0
        if p_t != p_t:
            p_t = 1.0
        wc = _safe_wilcoxon(agent, base)
        return {
            "comparison": f"agentic_vs_{name}",
            "paired_t_statistic": float(t_stat),
            "paired_t_pvalue": float(p_t),
            "wilcoxon": wc,
            "mean_delta_agent_minus_baseline": float(statistics.mean(a - b for a, b in zip(agent, base))),
        }

    return {
        "seeds": list(seeds),
        "inject_events": inject_events,
        "metric_col": metric_col,
        "rolling_window": rolling_window,
        "summary": {
            "agentic_f1": _summ(agent_f1),
            "agentic_precision": _summ(agent_prec),
            "agentic_recall": _summ(agent_rec),
            "baseline_1_f1": _summ(b1_f1),
            "baseline_2_f1": _summ(b2_f1),
            "baseline_3_f1": _summ(b3_f1),
            "baseline_1_precision": _summ(b1_prec),
            "baseline_1_recall": _summ(b1_rec),
            "baseline_2_precision": _summ(b2_prec),
            "baseline_2_recall": _summ(b2_rec),
            "baseline_3_precision": _summ(b3_prec),
            "baseline_3_recall": _summ(b3_rec),
            "root_cause_top1_accuracy": _summ(rc1),
            "root_cause_top3_accuracy": _summ(rc3),
        },
        "paired_tests_f1": [
            _paired(agent_f1, b1_f1, "baseline_1_static_threshold"),
            _paired(agent_f1, b2_f1, "baseline_2_z_only"),
            _paired(agent_f1, b3_f1, "baseline_3_manual_script"),
        ],
        "caveat": "Small number of seeds yields exploratory p-values; add more seeds or bootstrap for stability.",
        "per_seed": per_seed,
    }
