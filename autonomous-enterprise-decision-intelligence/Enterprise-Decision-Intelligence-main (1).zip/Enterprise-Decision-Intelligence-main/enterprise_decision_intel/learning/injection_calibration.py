"""
Learn small per-action utility adjustments from repeated inject-mode runs.

Uses injection ground-truth dimension keys (synthetic labels) as supervision: we reward
top-ranked actions that align with the injected dimension (channel vs region vs product_tier, etc.)
using the same heuristics as DecisionAgent._context_boost. No real labeled interventions required.

Output is a JSON-serializable map action_id -> additive boost in [roughly -0.02, 0.06] applied on top
of deterministic utility in DecisionAgent.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any

import pandas as pd

from enterprise_decision_intel.config import DetectionConfig
from enterprise_decision_intel.evaluation.injection import inject_controlled_anomalies
from enterprise_decision_intel.pipeline import run_dataset_from_df


def _dim_from_gt(gt: str) -> str:
    if not gt or ":" not in gt:
        return ""
    return str(gt.split(":", 1)[0]).strip().lower()


def _action_prefers_dimension(action_id: str, dim: str) -> bool:
    """Heuristic alignment (mirrors decision context boosts)."""
    if dim == "channel":
        return action_id in (
            "promo_surge",
            "creative_refresh",
            "audience_retarget",
            "search_shopping_feed",
            "checkout_audit",
        )
    if dim == "region":
        return action_id in ("geo_campaign", "partnerships_local", "inventory_rebalance")
    if dim == "product_tier":
        return action_id in ("inventory_rebalance", "pricing_promo_test")
    if dim == "customer_segment":
        return action_id in ("crm_outreach", "promo_surge", "audience_retarget")
    return False


def fit_learned_boosts(
    df: pd.DataFrame,
    seeds: list[int],
    *,
    inject_events: int = 10,
    metric_col: str = "revenue",
    rolling_window: int = 14,
    detection: DetectionConfig | None = None,
    eta: float = 0.012,
) -> dict[str, Any]:
    """
    Aggregate alignment counts across seeds: when top-1 action matches dimension heuristic for GT, reward.
    """
    det = detection or DetectionConfig(rolling_window=rolling_window)
    align_hits: dict[str, float] = defaultdict(float)
    align_miss: dict[str, float] = defaultdict(float)
    days_scored = 0

    for seed in seeds:
        inj = inject_controlled_anomalies(df, inject_events, seed=seed)
        res = run_dataset_from_df(
            inj.df,
            metric_col=metric_col,
            rolling_window=rolling_window,
            detection=det,
        )
        for i, row in enumerate(res.rows):
            gt = inj.root_cause_keys[i] if i < len(inj.root_cause_keys) else None
            if not gt or not row.get("is_anomaly"):
                continue
            acts = row.get("ranked_actions") or []
            if not acts:
                continue
            top1 = str(acts[0].get("id") or "")
            dim = _dim_from_gt(gt)
            if not dim:
                continue
            days_scored += 1
            if _action_prefers_dimension(top1, dim):
                align_hits[top1] += 1
            else:
                align_miss[top1] += 1
                # nudge actions that would have been correct
                for aid in (
                    "promo_surge",
                    "geo_campaign",
                    "creative_refresh",
                    "inventory_rebalance",
                    "crm_outreach",
                ):
                    if _action_prefers_dimension(aid, dim):
                        align_hits[aid] += 0.25  # fractional credit toward preferred set

    boosts: dict[str, float] = {}
    all_ids = set(align_hits.keys()) | set(align_miss.keys())
    for aid in all_ids:
        h = float(align_hits.get(aid, 0.0))
        m = float(align_miss.get(aid, 0.0))
        raw = eta * (h - m)
        boosts[aid] = float(max(-0.02, min(0.06, raw)))

    return {
        "learned_boosts": boosts,
        "meta": {
            "seeds": list(seeds),
            "inject_events": inject_events,
            "scored_anomaly_days": days_scored,
            "eta": eta,
            "note": "Boosts are additive to utility; fit on inject GT + heuristic alignment, not real post-intervention labels.",
        },
    }
