import numpy as np
import matplotlib
import sys
import matplotlib.lines as mlines
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
plt.rc('text', usetex=False)

matplotlib.use('Agg')

import matplotlib.pyplot as plt

def plots_check_equil(list_molecule_types,output_folder,step_index,mean_square_end_to_end_distance_list,square_radius_of_gyration_list,time_correlation_end_to_end_vector,box_dim_list):

	#############################
	# Specify plot styling and placement 
	#############################

	style_list = ['bo','gv','rs', 'kp','mD','cD']

	fig = plt.figure()

	xbase = 0.2
	ybase = 0.3
	y_int = 1.2
	x_int = 1.2
	size_x = 1
	size_y = 1

	num_rows = 2

	marker_size=6
	marker_edgewidth=0.0

	y_base_2 = ybase + (num_rows-1)*y_int*1.3

	# First row
	ax1 = fig.add_axes([xbase, y_base_2, size_x, size_y])
	ax2 = fig.add_axes([xbase+x_int, y_base_2, size_x, size_y])
	# Second row
	ax3 = fig.add_axes([xbase, y_base_2-y_int, size_x, size_y])
	ax4 = fig.add_axes([xbase+x_int, y_base_2-y_int, size_x, size_y])


	#############################
	# Create plots
	#############################

	for ii in range(0,len(list_molecule_types)):
	    label_str = 'Mol_type: ' + str(ii)    
	    ax1.plot(step_index, mean_square_end_to_end_distance_list[ii], style_list[ii],label=label_str, markersize=marker_size, markeredgewidth=marker_edgewidth)
	    ax2.plot(step_index, square_radius_of_gyration_list[ii], style_list[ii],label=label_str, markersize=marker_size, markeredgewidth=marker_edgewidth)
	    ax4.plot(step_index, time_correlation_end_to_end_vector[ii], style_list[ii],label=label_str, markersize=marker_size, markeredgewidth=marker_edgewidth)

	ax3.plot(step_index, box_dim_list, style_list[ii],label=label_str, markersize=marker_size, markeredgewidth=marker_edgewidth)



	#############################
	# Set plot display preferences
	#############################
	ax1.set_ylabel('R^2 list')
	ax1.set_xlabel('Steps')
	ax1.set_xscale("log")
	# ax1.set_yscale("log")
	ax1.legend(fontsize='small',loc=1)

	ax2.set_ylabel('R_g^2 list')
	ax2.set_xlabel('Step')
	ax1.set_xscale("log")
	# ax1.set_yscale("log")
	ax2.legend(fontsize='small',loc=1)

	ax3.set_ylabel('Box size')
	ax3.set_xlabel('Steps')
	ax3.set_xscale("log")
	# ax3.set_yscale("log")
	ax3.legend(fontsize='small',loc=1)

	ax4.set_ylabel('End-to-end dist auto correlation')
	ax4.set_xlabel('Steps')
	ax4.set_xscale("log")
	# ax4.set_yscale("log")
	ax4.legend(fontsize='small',loc=1)


	plt.savefig(output_folder+'/Summary_of_results.png',bbox_inches="tight")
	# plt.show()





### Template obtained from /Users/christiancaar/Documents/1.Research/A-R_Research/Research/simulations/python_code/jupyter/1.basic_tools/Plotting_templates/Data_series_plots.ipynb
### on 2019/10/2
#### PLOT TEMPLATE: Plot a data series in a format suitable for publications

# # PATCH: If 'Times New Roman' font appears only in bold, run the following three lines.
# import matplotlib 
# del matplotlib.font_manager.weight_dict['roman']
# matplotlib.font_manager._rebuild()

def plot_csv_log_log(data_sets,plot_title,x_axis_title,y_axis_title,series_title,color_val,style_list,linewidth_list,marker_pref,eye_guides,eye_guides_styles,eye_guides_labels):
    
	fig = plt.figure()

	xbase = 0.2
	ybase = 0.3
	y_int = 1.2
	x_int = 1.2
	size_x = 1
	size_y = 1

	num_rows = 3
	y_base_2 = ybase + (num_rows-1)*y_int
	y_base_3 = ybase + (num_rows-2)*y_int

	marker_size = marker_pref[0]
	marker_edgewidth = marker_pref[1]
	markerfacecolor_value = marker_pref[2]


	# First row
	ax1 = fig.add_axes([xbase, y_base_2, size_x, size_y])#,ylim=(20,100))#,ylim=(1,1000))#,xlim=[0.1,10],ylim=(0.005,1))

	#############################
	# Create plots
	#############################

	# Plot data
	for iii in range(0,len(data_sets)):
		if markerfacecolor_value == '':
			ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii], color=color_val[iii],label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii])
		else:
			ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii], color=color_val[iii],label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii],markerfacecolor=markerfacecolor_value)

	# Plot guides to the eye with specific power
	for iii in range(0,len(eye_guides)):
	    ax1.plot(eye_guides[iii][:,0], eye_guides[iii][:,1], eye_guides_styles[iii],label=eye_guides_labels[iii], markersize=marker_size, markeredgewidth=marker_edgewidth)

	    
	#############################
	# Set plot display preferences
	#############################

	# Scale of x and y axis
	axis_scale = "log"
	ax1.set_xscale(axis_scale)
	ax1.set_yscale(axis_scale)

	# Format of plot and axis titles
	title_font = {'fontname':'Times New Roman', 'size':'20', 'color':'black'}
	#               'fontweight':"light"}
	axis_font = {'fontname':'Times New Roman', 'size':'20'}

	ax1.set_title(plot_title,**title_font)
	ax1.set_xlabel(x_axis_title,**axis_font)
	ax1.set_ylabel(y_axis_title, **axis_font)

	# Set legend location
	ax1.legend(fontsize='small',loc=1)
	ax1.legend(loc='upper center', bbox_to_anchor=(0.5, -0.18),ncol=marker_pref[3])

	# Set up major and minor ticks


	major_tick_lw = [10,1.5]
	minor_tick_lw = [7,1]
	size_label = 10

	# Set thick label font
	tick_font = {'fontsize': '20', 'fontname' : 'Times New Roman'}

	ax1.xaxis.set_minor_locator( matplotlib.ticker.FixedLocator( ax1.get_xticks(minor=True) ) ) 
	ax1.xaxis.set_major_locator( matplotlib.ticker.FixedLocator( ax1.get_xticks() ) ) 
	ax1.yaxis.set_minor_locator( matplotlib.ticker.FixedLocator( ax1.get_yticks(minor=True) ) ) 
	ax1.yaxis.set_major_locator( matplotlib.ticker.FixedLocator( ax1.get_yticks() ) ) 

	ax1.set_xticklabels( labels = ax1.get_xticks(minor=True), fontdict = tick_font, minor = True) 
	ax1.set_xticklabels( labels = ax1.get_xticks(), fontdict = tick_font) 
	ax1.set_yticklabels( labels = ax1.get_yticks(minor=True), fontdict = tick_font, minor = True) 
	ax1.set_yticklabels( labels = ax1.get_yticks(), fontdict = tick_font) 

	# Set tick thickness and length
	ax1.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1])
	ax1.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1], labelsize = 12)  
	ax1.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1])
	ax1.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1], labelsize = 12)


	# Set up mirror axes
	ax2 = ax1.twinx()
	ax3 = ax1.twiny()

	ax2.set_xscale(axis_scale)
	ax2.set_yscale(axis_scale)

	ax3.set_xscale(axis_scale)
	ax3.set_yscale(axis_scale)

	ax2.set_xlim(ax1.get_xlim())
	ax2.set_ylim(ax1.get_ylim())

	ax3.set_xlim(ax1.get_xlim())
	ax3.set_ylim(ax1.get_ylim())

	ax2.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax2.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	ax2.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax2.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')

	ax3.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax3.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	ax3.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax3.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')

	return fig, ax1

### Template obtained from /Users/christiancaar/Documents/1.Research/A-R_Research/Research/simulations/python_code/jupyter/1.basic_tools/Plotting_templates/Data_series_plots.ipynb
### on 2019/10/2
#### PLOT TEMPLATE: Plot a data series in a format suitable for publications



# # PATCH: If 'Times New Roman' font appears only in bold, run the following three lines.
# import matplotlib 
# del matplotlib.font_manager.weight_dict['roman']
# matplotlib.font_manager._rebuild()


def plot_csv_log_lin(data_sets,plot_title,x_axis_title,y_axis_title,series_title,color_val,style_list,linewidth_list,marker_pref,eye_guides,eye_guides_styles,eye_guides_labels):

	fig = plt.figure()

	xbase = 0.2
	ybase = 0.3
	y_int = 1.2
	x_int = 1.2
	size_x = 1
	size_y = 1

	num_rows = 3
	y_base_2 = ybase + (num_rows-1)*y_int
	y_base_3 = ybase + (num_rows-2)*y_int

	# marker_size=6
	# marker_edgewidth=.0


	# major_tick_lw = [10,1.5]
	# minor_tick_lw = [7,1]
	# size_label = 10

	marker_size = marker_pref[0]
	marker_edgewidth = marker_pref[1]
	markerfacecolor_value = marker_pref[2]

	# First row
	#     ax1 = fig.add_axes([xbase, y_base_2, size_x, size_y])#,ylim=(20,100))#,ylim=(1,1000))#,xlim=[0.1,10],ylim=(0.005,1))

	ax1 = fig.add_axes([xbase, y_base_2, size_x, size_y])#,ylim=(0,0.35))#,ylim=(1,1000))#,xlim=[0.1,10],ylim=(0.005,1))


	#############################
	# Create plots
	#############################

	# Plot data
	for iii in range(0,len(data_sets)):
	    # ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii],label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii])
		if markerfacecolor_value == '':
			ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii],color=color_val[iii],label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii])
		else:
			ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii],color=color_val[iii],label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii],markerfacecolor=markerfacecolor_value)

	# Plot guides to the eye with specific power
	for iii in range(0,len(eye_guides)):
	    ax1.plot(eye_guides[iii][:,0], eye_guides[iii][:,1], eye_guides_styles[iii],label=eye_guides_labels[iii], markersize=marker_size, markeredgewidth=marker_edgewidth)

	    
	#############################
	# Set plot display preferences
	#############################

	# Scale of x and y axis
	axis_scale = "log"
	axis_scale_2 = 'linear'
	ax1.set_xscale(axis_scale)
	ax1.set_yscale(axis_scale_2)

	# Format of plot and axis titles
	title_font = {'fontname':'Times New Roman', 'size':'20', 'color':'black'}
	#               'fontweight':"light"}
	axis_font = {'fontname':'Times New Roman', 'size':'20'}

	ax1.set_title(plot_title,**title_font)
	ax1.set_xlabel(x_axis_title,**axis_font)
	ax1.set_ylabel(y_axis_title, **axis_font)

	# Set legend location
	ax1.legend(fontsize='small',loc=1)
	ax1.legend(loc='upper center', bbox_to_anchor=(0.5, -.18),ncol=4)

	# Set up major and minor ticks


	major_tick_lw = [10,1.5]
	minor_tick_lw = [7,1]
	size_label = 10

	# Set thick label font
	tick_font = {'fontsize': '20', 'fontname' : 'Times New Roman'}

	ax1.xaxis.set_minor_locator( matplotlib.ticker.FixedLocator( ax1.get_xticks(minor=True) ) ) 
	ax1.xaxis.set_major_locator( matplotlib.ticker.FixedLocator( ax1.get_xticks() ) ) 
	ax1.yaxis.set_minor_locator( matplotlib.ticker.FixedLocator( ax1.get_yticks(minor=True) ) ) 
	ax1.yaxis.set_major_locator( matplotlib.ticker.FixedLocator( ax1.get_yticks() ) ) 

	ax1.set_xticklabels( labels = ax1.get_xticks(minor=True), fontdict = tick_font, minor = True) 
	ax1.set_xticklabels( labels = ax1.get_xticks(), fontdict = tick_font) 
	ax1.set_yticklabels( labels = ax1.get_yticks(minor=True), fontdict = tick_font, minor = True) 
	ax1.set_yticklabels( labels = ax1.get_yticks(), fontdict = tick_font) 


	# Set tick thickness and length
	ax1.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1])
	ax1.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1], labelsize = 12)  
	ax1.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1])
	ax1.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1], labelsize = 12)



	# Set up mirror axes
	ax2 = ax1.twinx()
	ax3 = ax1.twiny()

	ax2.set_xscale(axis_scale)
	ax2.set_yscale(axis_scale_2)

	ax3.set_xscale(axis_scale)
	ax3.set_yscale(axis_scale_2)

	ax2.set_xlim(ax1.get_xlim())
	ax2.set_ylim(ax1.get_ylim())

	ax3.set_xlim(ax1.get_xlim())
	ax3.set_ylim(ax1.get_ylim())

	ax2.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax2.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	ax2.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax2.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')

	ax3.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax3.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	ax3.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax3.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')



def plot_csv_lin_log(data_sets,plot_title,x_axis_title,y_axis_title,series_title,color_val,style_list,linewidth_list,marker_pref,eye_guides,eye_guides_styles,eye_guides_labels):

	fig = plt.figure()



	xbase = 0.2
	ybase = 0.3
	y_int = 1.2
	x_int = 1.2
	size_x = 1
	size_y = 1

	num_rows = 3
	y_base_2 = ybase + (num_rows-1)*y_int
	y_base_3 = ybase + (num_rows-2)*y_int

	# marker_size=6
	# marker_edgewidth=.0


	# major_tick_lw = [10,1.5]
	# minor_tick_lw = [7,1]
	# size_label = 10

	marker_size = marker_pref[0]
	marker_edgewidth = marker_pref[1]
	markerfacecolor_value = marker_pref[2]

	# First row
	#     ax1 = fig.add_axes([xbase, y_base_2, size_x, size_y])#,ylim=(20,100))#,ylim=(1,1000))#,xlim=[0.1,10],ylim=(0.005,1))

	ax1 = fig.add_axes([xbase, y_base_2, size_x, size_y])#,ylim=(0,0.35))#,ylim=(1,1000))#,xlim=[0.1,10],ylim=(0.005,1))


	#############################
	# Create plots
	#############################

	# Plot data
	for iii in range(0,len(data_sets)):
	    # ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii],label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii])
		if markerfacecolor_value == '':
			ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii],color=color_val[iii],label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii])
		else:
			ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii],color=color_val[iii],label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii],markerfacecolor=markerfacecolor_value)

	# Plot guides to the eye with specific power
	for iii in range(0,len(eye_guides)):
	    ax1.plot(eye_guides[iii][:,0], eye_guides[iii][:,1], eye_guides_styles[iii],label=eye_guides_labels[iii], markersize=marker_size, markeredgewidth=marker_edgewidth)

	    
	#############################
	# Set plot display preferences
	#############################

	# Scale of x and y axis
	axis_scale = "linear"
	axis_scale_2 = 'log'
	ax1.set_xscale(axis_scale)
	ax1.set_yscale(axis_scale_2)

	# Format of plot and axis titles
	title_font = {'fontname':'Times New Roman', 'size':'20', 'color':'black'}
	#               'fontweight':"light"}
	axis_font = {'fontname':'Times New Roman', 'size':'20'}

	ax1.set_title(plot_title,**title_font)
	ax1.set_xlabel(x_axis_title,**axis_font)
	ax1.set_ylabel(y_axis_title, **axis_font)

	# Set legend location
	ax1.legend(fontsize='small',loc=1)
	ax1.legend(loc='upper center', bbox_to_anchor=(0.5, -.18),ncol=4)

	# Set up major and minor ticks


	major_tick_lw = [10,1.5]
	minor_tick_lw = [7,1]
	size_label = 10

	# Set thick label font
	tick_font = {'fontsize': '20', 'fontname' : 'Times New Roman'}

	ax1.xaxis.set_minor_locator( matplotlib.ticker.FixedLocator( ax1.get_xticks(minor=True) ) ) 
	ax1.xaxis.set_major_locator( matplotlib.ticker.FixedLocator( ax1.get_xticks() ) ) 
	ax1.yaxis.set_minor_locator( matplotlib.ticker.FixedLocator( ax1.get_yticks(minor=True) ) ) 
	ax1.yaxis.set_major_locator( matplotlib.ticker.FixedLocator( ax1.get_yticks() ) ) 

	ax1.set_xticklabels( labels = ax1.get_xticks(minor=True), fontdict = tick_font, minor = True) 
	ax1.set_xticklabels( labels = ax1.get_xticks(), fontdict = tick_font) 
	ax1.set_yticklabels( labels = ax1.get_yticks(minor=True), fontdict = tick_font, minor = True) 
	ax1.set_yticklabels( labels = ax1.get_yticks(), fontdict = tick_font) 


	# Set tick thickness and length
	ax1.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1])
	ax1.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1], labelsize = 12)  
	ax1.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1])
	ax1.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1], labelsize = 12)


	# Set up mirror axes
	ax2 = ax1.twinx()
	ax3 = ax1.twiny()

	ax2.set_xscale(axis_scale)
	ax2.set_yscale(axis_scale_2)

	ax3.set_xscale(axis_scale)
	ax3.set_yscale(axis_scale_2)

	ax2.set_xlim(ax1.get_xlim())
	ax2.set_ylim(ax1.get_ylim())

	ax3.set_xlim(ax1.get_xlim())
	ax3.set_ylim(ax1.get_ylim())

	ax2.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax2.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	ax2.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax2.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')

	ax3.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax3.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	ax3.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax3.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
# 
	return fig


### Template obtained from /Users/christiancaar/Documents/1.Research/A-R_Research/Research/simulations/python_code/jupyter/1.basic_tools/Plotting_templates/Data_series_plots.ipynb
### on 2019/10/2
#### PLOT TEMPLATE: Plot a data series in a format suitable for publications

# # PATCH: If 'Times New Roman' font appears only in bold, run the following three lines.
# import matplotlib 
# del matplotlib.font_manager.weight_dict['roman']
# matplotlib.font_manager._rebuild()

def plot_csv_lin_lin(data_sets,plot_title,x_axis_title,y_axis_title,series_title,color_val,style_list,linewidth_list,marker_pref,eye_guides,eye_guides_styles,eye_guides_labels):

	fig = plt.figure()

	xbase = 0.2
	ybase = 0.3
	y_int = 1.2
	x_int = 1.2
	size_x = 1
	size_y = 1

	num_rows = 3
	y_base_2 = ybase + (num_rows-1)*y_int
	y_base_3 = ybase + (num_rows-2)*y_int

	marker_size = marker_pref[0]
	marker_edgewidth = marker_pref[1]
	markerfacecolor_value = marker_pref[2]


	# First row
	#     ax1 = fig.add_axes([xbase, y_base_2, size_x, size_y])#,ylim=(20,100))#,ylim=(1,1000))#,xlim=[0.1,10],ylim=(0.005,1))

	ax1 = fig.add_axes([xbase, y_base_2, size_x, size_y])#,ylim=(0,0.35))#,ylim=(1,1000))#,xlim=[0.1,10],ylim=(0.005,1))


	#############################
	# Create plots
	#############################

	# Plot data
	for iii in range(0,len(data_sets)):
		if markerfacecolor_value == '':
			ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii], color=color_val[iii], label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii])
		else:
			ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii], color=color_val[iii], label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii],markerfacecolor=markerfacecolor_value)

	# Plot guides to the eye with specific power
	for iii in range(0,len(eye_guides)):
	    ax1.plot(eye_guides[iii][:,0], eye_guides[iii][:,1], eye_guides_styles[iii],label=eye_guides_labels[iii], markersize=marker_size, markeredgewidth=marker_edgewidth)

	    
	#############################
	# Set plot display preferences
	#############################

	# Scale of x and y axis
	axis_scale = "linear"
	axis_scale_2 = 'linear'
	ax1.set_xscale(axis_scale)
	ax1.set_yscale(axis_scale_2)

	# Format of plot and axis titles
	title_font = {'fontname':'Times New Roman', 'size':'20', 'color':'black'}
	#               'fontweight':"light"}
	axis_font = {'fontname':'Times New Roman', 'size':'20'}

	ax1.set_title(plot_title,**title_font)
	ax1.set_xlabel(x_axis_title,**axis_font)
	ax1.set_ylabel(y_axis_title, **axis_font)

	# Set legend location
	ax1.legend(fontsize='small',loc=1)
	ax1.legend(loc='upper center', bbox_to_anchor=(0.5, -.18),ncol=marker_pref[3])

	# Set up major and minor ticks


	major_tick_lw = [10,1.5]
	minor_tick_lw = [7,1]
	size_label = 10

	# Set thick label font
	tick_font = {'fontsize': '20', 'fontname' : 'Times New Roman'}

	ax1.xaxis.set_minor_locator( matplotlib.ticker.FixedLocator( ax1.get_xticks(minor=True) ) ) 
	ax1.xaxis.set_major_locator( matplotlib.ticker.FixedLocator( ax1.get_xticks() ) ) 
	ax1.yaxis.set_minor_locator( matplotlib.ticker.FixedLocator( ax1.get_yticks(minor=True) ) ) 
	ax1.yaxis.set_major_locator( matplotlib.ticker.FixedLocator( ax1.get_yticks() ) ) 

	ax1.set_xticklabels( labels = ax1.get_xticks(minor=True), fontdict = tick_font, minor = True) 
	ax1.set_xticklabels( labels = ax1.get_xticks(), fontdict = tick_font) 
	ax1.set_yticklabels( labels = ax1.get_yticks(minor=True), fontdict = tick_font, minor = True) 
	ax1.set_yticklabels( labels = ax1.get_yticks(), fontdict = tick_font) 


	# Set tick thickness and length
	ax1.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1])
	ax1.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1], labelsize = 12)  
	ax1.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1])
	ax1.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1], labelsize = 12)


	# Set up mirror axes
	ax2 = ax1.twinx()
	ax3 = ax1.twiny()

	ax2.set_xscale(axis_scale)
	ax2.set_yscale(axis_scale_2)

	ax3.set_xscale(axis_scale)
	ax3.set_yscale(axis_scale_2)

	ax2.set_xlim(ax1.get_xlim())
	ax2.set_ylim(ax1.get_ylim())

	ax3.set_xlim(ax1.get_xlim())
	ax3.set_ylim(ax1.get_ylim())

	ax2.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax2.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	ax2.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax2.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')

	ax3.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax3.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	ax3.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax3.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	
	return fig


### Template obtained from /Users/christiancaar/Documents/1.Research/A-R_Research/Research/simulations/python_code/jupyter/1.basic_tools/Plotting_templates/Data_series_plots.ipynb
### on 2019/10/2
#### PLOT TEMPLATE: Plot a data series in a format suitable for publications



# # PATCH: If 'Times New Roman' font appears only in bold, run the following three lines.
# import matplotlib 
# del matplotlib.font_manager.weight_dict['roman']
# matplotlib.font_manager._rebuild()


def plot_csv_log_log_wlim(data_sets,x_lim,y_lim,plot_title,x_axis_title,y_axis_title,series_title,color_val,style_list,linewidth_list,marker_pref,eye_guides,eye_guides_styles,eye_guides_labels):

	fig = plt.figure()

	xbase = 0.2
	ybase = 0.3
	y_int = 1.2
	x_int = 1.2
	size_x = 1
	size_y = 1

	num_rows = 3
	y_base_2 = ybase + (num_rows-1)*y_int
	y_base_3 = ybase + (num_rows-2)*y_int

	marker_size = marker_pref[0]
	marker_edgewidth = marker_pref[1]
	markerfacecolor_value = marker_pref[2]

	# First row
	if x_lim[0]=='No':
		ax1 = fig.add_axes([xbase, y_base_2, size_x, size_y])#,ylim=(20,100))#,ylim=(1,1000))#,xlim=[0.1,10],ylim=(0.005,1))
	else:
		ax1 = fig.add_axes([xbase, y_base_2, size_x, size_y],xlim=(x_lim[0],x_lim[1]),ylim=(y_lim[0],y_lim[1]))


	#############################
	# Create plots
	#############################

	# Plot data
	for iii in range(0,len(data_sets)):
		if markerfacecolor_value == '':
			ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii],color=color_val[iii], label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii])
		else:
			ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii],color=color_val[iii], label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii],markerfacecolor=markerfacecolor_value)

	# Plot guides to the eye with specific power
	for iii in range(0,len(eye_guides)):
	    ax1.plot(eye_guides[iii][:,0], eye_guides[iii][:,1], eye_guides_styles[iii],label=eye_guides_labels[iii], markersize=marker_size, markeredgewidth=marker_edgewidth)

	    
	#############################
	# Set plot display preferences
	#############################

	# Scale of x and y axis
	axis_scale = "log"
	ax1.set_xscale(axis_scale)
	ax1.set_yscale(axis_scale)

	# Format of plot and axis titles
	title_font = {'fontname':'Times New Roman', 'size':'20', 'color':'black'}
	#               'fontweight':"light"}
	axis_font = {'fontname':'Times New Roman', 'size':'20'}

	ax1.set_title(plot_title,**title_font)
	ax1.set_xlabel(x_axis_title,**axis_font)
	ax1.set_ylabel(y_axis_title, **axis_font)

	# Set legend location
	ax1.legend(fontsize='small',loc=1)
	ax1.legend(loc='upper center', bbox_to_anchor=(0.5, -.18),ncol=marker_pref[3])

	# Set up major and minor ticks


	major_tick_lw = [10,1.5]
	minor_tick_lw = [7,1]
	size_label = 10

	# Set thick label font
	tick_font = {'fontsize': '20', 'fontname' : 'Times New Roman'}

	ax1.xaxis.set_minor_locator( matplotlib.ticker.FixedLocator( ax1.get_xticks(minor=True) ) ) 
	ax1.xaxis.set_major_locator( matplotlib.ticker.FixedLocator( ax1.get_xticks() ) ) 
	ax1.yaxis.set_minor_locator( matplotlib.ticker.FixedLocator( ax1.get_yticks(minor=True) ) ) 
	ax1.yaxis.set_major_locator( matplotlib.ticker.FixedLocator( ax1.get_yticks() ) ) 

	ax1.set_xticklabels( labels = ax1.get_xticks(minor=True), fontdict = tick_font, minor = True) 
	ax1.set_xticklabels( labels = ax1.get_xticks(), fontdict = tick_font) 
	ax1.set_yticklabels( labels = ax1.get_yticks(minor=True), fontdict = tick_font, minor = True) 
	ax1.set_yticklabels( labels = ax1.get_yticks(), fontdict = tick_font) 


	# Set tick thickness and length
	ax1.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1])
	ax1.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1], labelsize = 12)  
	ax1.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1])
	ax1.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1], labelsize = 12)


	# Set up mirror axes
	ax2 = ax1.twinx()
	ax3 = ax1.twiny()

	ax2.set_xscale(axis_scale)
	ax2.set_yscale(axis_scale)

	ax3.set_xscale(axis_scale)
	ax3.set_yscale(axis_scale)

	ax2.set_xlim(ax1.get_xlim())
	ax2.set_ylim(ax1.get_ylim())

	ax3.set_xlim(ax1.get_xlim())
	ax3.set_ylim(ax1.get_ylim())

	ax2.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax2.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	ax2.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax2.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')

	ax3.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax3.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	ax3.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax3.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')

	return ax1

def plot_csv_lin_lin_wlim(data_sets,x_lim,y_lim,plot_title,x_axis_title,y_axis_title,series_title,color_val,style_list,linewidth_list,marker_pref,eye_guides,eye_guides_styles,eye_guides_labels):

	fig = plt.figure()

	xbase = 0.2
	ybase = 0.3
	y_int = 1.2
	x_int = 1.2
	size_x = 1
	size_y = 1

	num_rows = 3
	y_base_2 = ybase + (num_rows-1)*y_int
	y_base_3 = ybase + (num_rows-2)*y_int

	marker_size = marker_pref[0]
	marker_edgewidth = marker_pref[1]
	markerfacecolor_value = marker_pref[2]

	# First row
	if x_lim[0]=='No':
		ax1 = fig.add_axes([xbase, y_base_2, size_x, size_y])#,ylim=(20,100))#,ylim=(1,1000))#,xlim=[0.1,10],ylim=(0.005,1))
	else:
		ax1 = fig.add_axes([xbase, y_base_2, size_x, size_y],xlim=(x_lim[0],x_lim[1]),ylim=(y_lim[0],y_lim[1]))


	#############################
	# Create plots
	#############################

	# Plot data
	for iii in range(0,len(data_sets)):
		if markerfacecolor_value == '':
			ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii],color=color_val[iii],label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii])
		else:
			ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii],color=color_val[iii],label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii],markerfacecolor=markerfacecolor_value)

	# Plot guides to the eye with specific power
	for iii in range(0,len(eye_guides)):
	    ax1.plot(eye_guides[iii][:,0], eye_guides[iii][:,1], eye_guides_styles[iii],label=eye_guides_labels[iii], markersize=marker_size, markeredgewidth=marker_edgewidth)

	    
	#############################
	# Set plot display preferences
	#############################

	# Scale of x and y axis
	axis_scale = "linear"
	ax1.set_xscale(axis_scale)
	ax1.set_yscale(axis_scale)

	# Format of plot and axis titles
	title_font = {'fontname':'Times New Roman', 'size':'20', 'color':'black'}
	#               'fontweight':"light"}
	axis_font = {'fontname':'Times New Roman', 'size':'20'}

	ax1.set_title(plot_title,**title_font)
	ax1.set_xlabel(x_axis_title,**axis_font)
	ax1.set_ylabel(y_axis_title, **axis_font)

	# Set legend location
	ax1.legend(fontsize='small',loc=1)
	ax1.legend(loc='upper center', bbox_to_anchor=(0.5, -.18),ncol=marker_pref[3])

	# Set up major and minor ticks


	major_tick_lw = [10,1.5]
	minor_tick_lw = [7,1]
	size_label = 10

	# Set thick label font
	tick_font = {'fontsize': '20', 'fontname' : 'Times New Roman'}

	ax1.xaxis.set_minor_locator( matplotlib.ticker.FixedLocator( ax1.get_xticks(minor=True) ) ) 
	ax1.xaxis.set_major_locator( matplotlib.ticker.FixedLocator( ax1.get_xticks() ) ) 
	ax1.yaxis.set_minor_locator( matplotlib.ticker.FixedLocator( ax1.get_yticks(minor=True) ) ) 
	ax1.yaxis.set_major_locator( matplotlib.ticker.FixedLocator( ax1.get_yticks() ) ) 

	ax1.set_xticklabels( labels = ax1.get_xticks(minor=True), fontdict = tick_font, minor = True) 
	ax1.set_xticklabels( labels = ax1.get_xticks(), fontdict = tick_font) 
	ax1.set_yticklabels( labels = ax1.get_yticks(minor=True), fontdict = tick_font, minor = True) 
	ax1.set_yticklabels( labels = ax1.get_yticks(), fontdict = tick_font) 


	# Set tick thickness and length
	ax1.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1])
	ax1.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1], labelsize = 12)  
	ax1.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1])
	ax1.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1], labelsize = 12)


	# Set up mirror axes
	ax2 = ax1.twinx()
	ax3 = ax1.twiny()

	ax2.set_xscale(axis_scale)
	ax2.set_yscale(axis_scale)

	ax3.set_xscale(axis_scale)
	ax3.set_yscale(axis_scale)

	ax2.set_xlim(ax1.get_xlim())
	ax2.set_ylim(ax1.get_ylim())

	ax3.set_xlim(ax1.get_xlim())
	ax3.set_ylim(ax1.get_ylim())

	ax2.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax2.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	ax2.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax2.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')

	ax3.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax3.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	ax3.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax3.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')

	return ax1


def plot_csv_lin_log_wlim(data_sets,x_lim,y_lim,plot_title,x_axis_title,y_axis_title,series_title,color_val,style_list,linewidth_list,marker_pref,eye_guides,eye_guides_styles,eye_guides_labels):

	fig = plt.figure()

	xbase = 0.2
	ybase = 0.3
	y_int = 1.2
	x_int = 1.2
	size_x = 1
	size_y = 1

	num_rows = 3
	y_base_2 = ybase + (num_rows-1)*y_int
	y_base_3 = ybase + (num_rows-2)*y_int

	marker_size = marker_pref[0]
	marker_edgewidth = marker_pref[1]
	markerfacecolor_value = marker_pref[2]

	# First row
	if x_lim[0]=='No':
		ax1 = fig.add_axes([xbase, y_base_2, size_x, size_y])#,ylim=(20,100))#,ylim=(1,1000))#,xlim=[0.1,10],ylim=(0.005,1))
	else:
		ax1 = fig.add_axes([xbase, y_base_2, size_x, size_y],xlim=(x_lim[0],x_lim[1]),ylim=(y_lim[0],y_lim[1]))


	#############################
	# Create plots
	#############################

	# Plot data
	for iii in range(0,len(data_sets)):
		if markerfacecolor_value == '':
			ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii],color=color_val[iii],label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii])
		else:
			ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii],color=color_val[iii],label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii],markerfacecolor=markerfacecolor_value)

	# Plot guides to the eye with specific power
	for iii in range(0,len(eye_guides)):
	    ax1.plot(eye_guides[iii][:,0], eye_guides[iii][:,1], eye_guides_styles[iii],label=eye_guides_labels[iii], markersize=marker_size, markeredgewidth=marker_edgewidth)

	    
	#############################
	# Set plot display preferences
	#############################

	# Scale of x and y axis
	axis_scale = "linear"
	axis_scale_y = "log"
	ax1.set_xscale(axis_scale)
	ax1.set_yscale(axis_scale_y)

	# Format of plot and axis titles
	title_font = {'fontname':'Times New Roman', 'size':'20', 'color':'black'}
	#               'fontweight':"light"}
	axis_font = {'fontname':'Times New Roman', 'size':'20'}

	ax1.set_title(plot_title,**title_font)
	ax1.set_xlabel(x_axis_title,**axis_font)
	ax1.set_ylabel(y_axis_title, **axis_font)

	# Set legend location
	ax1.legend(fontsize='small',loc=1)
	ax1.legend(loc='upper center', bbox_to_anchor=(0.5, -.18),ncol=marker_pref[3])

	# Set up major and minor ticks


	major_tick_lw = [10,1.5]
	minor_tick_lw = [7,1]
	size_label = 10

	# Set thick label font
	tick_font = {'fontsize': '20', 'fontname' : 'Times New Roman'}

	ax1.xaxis.set_minor_locator( matplotlib.ticker.FixedLocator( ax1.get_xticks(minor=True) ) ) 
	ax1.xaxis.set_major_locator( matplotlib.ticker.FixedLocator( ax1.get_xticks() ) ) 
	ax1.yaxis.set_minor_locator( matplotlib.ticker.FixedLocator( ax1.get_yticks(minor=True) ) ) 
	ax1.yaxis.set_major_locator( matplotlib.ticker.FixedLocator( ax1.get_yticks() ) ) 

	ax1.set_xticklabels( labels = ax1.get_xticks(minor=True), fontdict = tick_font, minor = True) 
	ax1.set_xticklabels( labels = ax1.get_xticks(), fontdict = tick_font) 
	ax1.set_yticklabels( labels = ax1.get_yticks(minor=True), fontdict = tick_font, minor = True) 
	ax1.set_yticklabels( labels = ax1.get_yticks(), fontdict = tick_font) 


	# Set tick thickness and length
	ax1.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1])
	ax1.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1], labelsize = 12)  
	ax1.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1])
	ax1.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1], labelsize = 12)



	# Set up mirror axes
	ax2 = ax1.twinx()
	ax3 = ax1.twiny()

	ax2.set_xscale(axis_scale)
	ax2.set_yscale(axis_scale_y)

	ax3.set_xscale(axis_scale)
	ax3.set_yscale(axis_scale_y)

	ax2.set_xlim(ax1.get_xlim())
	ax2.set_ylim(ax1.get_ylim())

	ax3.set_xlim(ax1.get_xlim())
	ax3.set_ylim(ax1.get_ylim())

	ax2.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax2.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	ax2.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax2.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')

	ax3.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax3.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	ax3.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax3.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')

	return ax1

	
def plot_csv_log_lin_wlim(data_sets,x_lim,y_lim,plot_title,x_axis_title,y_axis_title,series_title,color_val,style_list,linewidth_list,marker_pref,eye_guides,eye_guides_styles,eye_guides_labels):

	fig = plt.figure()

	xbase = 0.2
	ybase = 0.3
	y_int = 1.2
	x_int = 1.2
	size_x = 1
	size_y = 1

	num_rows = 3
	y_base_2 = ybase + (num_rows-1)*y_int
	y_base_3 = ybase + (num_rows-2)*y_int

	marker_size = marker_pref[0]
	marker_edgewidth = marker_pref[1]
	markerfacecolor_value = marker_pref[2]

	# First row
	if x_lim[0]=='No':
		ax1 = fig.add_axes([xbase, y_base_2, size_x, size_y])#,ylim=(20,100))#,ylim=(1,1000))#,xlim=[0.1,10],ylim=(0.005,1))
	else:
		ax1 = fig.add_axes([xbase, y_base_2, size_x, size_y],xlim=(x_lim[0],x_lim[1]),ylim=(y_lim[0],y_lim[1]))


	#############################
	# Create plots
	#############################

	# Plot data
	for iii in range(0,len(data_sets)):
		if markerfacecolor_value == '':
			ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii],color=color_val[iii],label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii])
		else:
			ax1.plot(data_sets[iii][:,0], data_sets[iii][:,1], style_list[iii],color=color_val[iii],label=series_title[iii], markersize=marker_size, markeredgewidth=marker_edgewidth,linewidth=linewidth_list[iii],markerfacecolor=markerfacecolor_value)

	# Plot guides to the eye with specific power
	for iii in range(0,len(eye_guides)):
	    ax1.plot(eye_guides[iii][:,0], eye_guides[iii][:,1], eye_guides_styles[iii],label=eye_guides_labels[iii], markersize=marker_size, markeredgewidth=marker_edgewidth)

	    
	#############################
	# Set plot display preferences
	#############################

	# Scale of x and y axis
	axis_scale = "log"
	axis_scale_y = "linear"
	ax1.set_xscale(axis_scale)
	ax1.set_yscale(axis_scale_y)

	# Format of plot and axis titles
	title_font = {'fontname':'Times New Roman', 'size':'20', 'color':'black'}
	#               'fontweight':"light"}
	axis_font = {'fontname':'Times New Roman', 'size':'20'}

	ax1.set_title(plot_title,**title_font)
	ax1.set_xlabel(x_axis_title,**axis_font)
	ax1.set_ylabel(y_axis_title, **axis_font)

	# Set legend location
	ax1.legend(fontsize='small',loc=1)
	ax1.legend(loc='upper center', bbox_to_anchor=(0.5, -.18),ncol=marker_pref[3])

	# Set up major and minor ticks


	major_tick_lw = [10,1.5]
	minor_tick_lw = [7,1]
	size_label = 10

	# Set thick label font
	tick_font = {'fontsize': '20', 'fontname' : 'Times New Roman'}

	ax1.xaxis.set_minor_locator( matplotlib.ticker.FixedLocator( ax1.get_xticks(minor=True) ) ) 
	ax1.xaxis.set_major_locator( matplotlib.ticker.FixedLocator( ax1.get_xticks() ) ) 
	ax1.yaxis.set_minor_locator( matplotlib.ticker.FixedLocator( ax1.get_yticks(minor=True) ) ) 
	ax1.yaxis.set_major_locator( matplotlib.ticker.FixedLocator( ax1.get_yticks() ) ) 

	ax1.set_xticklabels( labels = ax1.get_xticks(minor=True), fontdict = tick_font, minor = True) 
	ax1.set_xticklabels( labels = ax1.get_xticks(), fontdict = tick_font) 
	ax1.set_yticklabels( labels = ax1.get_yticks(minor=True), fontdict = tick_font, minor = True) 
	ax1.set_yticklabels( labels = ax1.get_yticks(), fontdict = tick_font) 


	# Set tick thickness and length
	ax1.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1])
	ax1.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1], labelsize = 12)  
	ax1.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1])
	ax1.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1], labelsize = 12)



	# Set up mirror axes
	ax2 = ax1.twinx()
	ax3 = ax1.twiny()

	ax2.set_xscale(axis_scale)
	ax2.set_yscale(axis_scale_y)

	ax3.set_xscale(axis_scale)
	ax3.set_yscale(axis_scale_y)

	ax2.set_xlim(ax1.get_xlim())
	ax2.set_ylim(ax1.get_ylim())

	ax3.set_xlim(ax1.get_xlim())
	ax3.set_ylim(ax1.get_ylim())

	ax2.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax2.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	ax2.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax2.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')

	ax3.xaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax3.xaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')
	ax3.yaxis.set_tick_params(direction='in', which='major', length=major_tick_lw[0], width=major_tick_lw[1],labelcolor='w')
	ax3.yaxis.set_tick_params(direction='in', which='minor', length=minor_tick_lw[0], width=minor_tick_lw[1],labelcolor='w')

	return ax1
